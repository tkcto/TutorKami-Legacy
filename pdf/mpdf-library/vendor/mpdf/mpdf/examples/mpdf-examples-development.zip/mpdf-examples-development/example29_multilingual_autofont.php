<?php

$html = '
<style>

body { font-family: sans; text-align: justify; }
p { font-family: sans; }
div { font-family: sans; }

</style>

<p>This document includes many languages. Selection of appropriate fonts is done automatically by using <b>AutoFont</b>. </p>
<h3>Pangrams - (from Wikipedia) </h3>
<p>The quick brown fox jumps over a lazy dog</p>

<h4>Bulgarian</h4>
<p>&#x416;&#x44a;&#x43b;&#x442;&#x430;&#x442;&#x430; &#x434;&#x44e;&#x43b;&#x44f; &#x431;&#x435;&#x448;&#x435; &#x449;&#x430;&#x441;&#x442;&#x43b;&#x438;&#x432;&#x430;, &#x447;&#x435; &#x43f;&#x443;&#x445;&#x44a;&#x442;, &#x43a;&#x43e;&#x439;&#x442;&#x43e; &#x446;&#x44a;&#x444;&#x43d;&#x430;, &#x437;&#x430;&#x43c;&#x440;&#x44a;&#x437;&#x43d;&#x430; &#x43a;&#x430;&#x442;&#x43e; &#x433;&#x44c;&#x43e;&#x43d;.</p>

<p>&#x417;&#x430; &#x43c;&#x438;&#x433; &#x431;&#x44f;&#x445; &#x432; &#x447;&#x443;&#x436;&#x434; &#x43f;&#x43b;&#x44e;&#x448;&#x435;&#x43d; &#x441;&#x43a;&#x44a;&#x440;&#x446;&#x430;&#x449; &#x444;&#x43e;&#x442;&#x44c;&#x43e;&#x439;&#x43b;. </p>

<h4>Catalan</h4>
<p>Jove xef, porti whisky amb quinze gla&#xe7;ons d\'hidrogen, coi! </p>

<p>Aqueix betzol, Jan, comprava whisky de figa </p>

<h4>Czech</h4>
<p>P&#x159;&#xed;li&#x161; &#x17e;lu&#x165;ou&#x10d;k&#xfd; k&#x16f;&#x148; &#xfa;p&#x11b;l &#x10f;&#xe1;belsk&#xe9; &#xf3;dy </p>

<h4>Danish</h4>
<p>H&#xf8;j bly gom vandt fr&#xe6;k sexquiz p&#xe5; wc </p>

<h4>Dutch</h4>
<p>Doch Bep, flink sexy qua vorm, zwijgt </p>

<p>Pa\'s wijze lynx bezag vroom het fikse aquaduct </p>

<h4>Finnish</h4>
<p>T&#xf6;rkylempij&#xe4; vongahdus </p>

<h4>French</h4>
<p>Portez ce vieux whisky au juge blond qui fume </p>

<p>B&#xe2;chez la queue du wagon-taxi avec les pyjamas du fakir </p>

<p>Voyez le brick g&#xe9;ant que j\'examine pr&#xe8;s du wharf </p>

<h4>German</h4>
<p>Victor jagt zw&#xf6;lf Boxk&#xe4;mpfer quer &#xfc;ber den gro&#xdf;en Sylter Deich </p>

<p>"Fix, Schwyz!" qu&#xe4;kt J&#xfc;rgen bl&#xf6;d vom Pa&#xdf; </p>

<p>"Falsches &#xdc;ben von Xylophonmusik qu&#xe4;lt jeden gr&#xf6;&#xdf;eren Zwerg"</p>

<h4>Hungarian</h4>
<p>Egy h&#x171;tlen vej&#xe9;t f&#xfc;l&#xf6;ncs&#xed;p&#x151;, d&#xfc;h&#xf6;s mexik&#xf3;i &#xfa;r Wessel&#xe9;nyin&#xe9;l m&#xe1;zol Quit&#xf3;ban. </p>

<h4>Icelandic</h4>
<p>K&#xe6;mi n&#xfd; &#xf6;xi h&#xe9;r ykist &#xfe;j&#xf3;fum n&#xfa; b&#xe6;&#xf0;i v&#xed;l og &#xe1;drepa </p>

<h4>Irish</h4>
<p>D\'fhuascail &#xcd;osa &#xda;rmhac na h&#xd3;ighe Beannaithe p&#xf3;r &#xc9;ava agus &#xc1;dhaimh </p>

<p>D\'&#x1e1f;uascail &#xcd;osa &#xda;r&#x1e41;ac na h&#xd3;i&#x121;e Beannai&#x1e6b;e p&#xf3;r &#xc9;a&#x1e03;a agus &#xc1;&#x1e0b;ai&#x1e41; </p>

<h4>Italian</h4>
<p>"Quel fez sghembo copre davanti" </p>

<p>"Ma la volpe col suo balzo ha raggiunto il quieto Fido" </p>

<p>"Quel vituperabile xenofobo zelante assaggia il whisky ed esclama: alleluja!" </p>

<h4>Lithuanian</h4>
<p>&#x12e;linkdama fechtuotojo &#x161;paga sublyk&#x10d;iojusi pragr&#x119;&#x17e;&#x117; apval&#x173; arb&#x16b;z&#x105; </p>

<h4>Norwegian</h4>
<p>V&#xe5;r s&#xe6;re Zulu fra bade&#xf8;ya spilte jo whist og quickstep i min taxi. </p>

<p>H&#xf8;vdingens kj&#xe6;re squaw f&#xe5;r litt pizza i Mexico by </p>

<h4>Polish</h4>
<p>P&#xf3;jd&#x17a;&#x17c;e, ki&#x144; t&#x119; chmurno&#x15b;&#x107; w g&#x142;&#x105;b flaszy! </p>

<p>Pchn&#x105;&#x107; w t&#x119; &#x142;&#xf3;d&#x17a; je&#x17c;a lub o&#x15b;m skrzy&#x144; fig. </p>

<p>M&#x119;&#x17c;ny b&#x105;d&#x17a;, chro&#x144; pu&#x142;k tw&#xf3;j i sze&#x15b;&#x107; flag. </p>

<h4>Portuguese</h4>
<p>Blitz prende ex-vesgo com cheque fajuto. </p>

<p>Gazeta publica hoje no jornal uma breve nota de faxina na quermesse. </p>

<p>&#xc0; noite, vov&#xf4; Kowalsky v&#xea; o &#xed;m&#xe3; cair no p&#xe9; do ping&#xfc;im queixoso e vov&#xf3; p&#xf5;e a&#xe7;&#xfa;car no ch&#xe1; de t&#xe2;maras do jabuti feliz. </p>

<p>Lu&#xed;s arg&#xfc;ia &#xe0; J&#xfa;lia que &#xab;bra&#xe7;&#xf5;es, f&#xe9;, ch&#xe1;, &#xf3;xido, p&#xf4;r, z&#xe2;ng&#xe3;o&#xbb; eram palavras do portugu&#xea;s. </p>

<h4>Romanian</h4>
<p>Gheorghe, obezul, a reu&#x15f;it s&#x103; ob&#x163;in&#x103; juc&#xe2;ndu-se un flux &#xee;n Quebec de o mie kilowa&#x163;ior&#x103;. </p>

<h4>Russian</h4>
<p>&#x412; &#x447;&#x430;&#x449;&#x430;&#x445; &#x44e;&#x433;&#x430; &#x436;&#x438;&#x43b; &#x431;&#x44b; &#x446;&#x438;&#x442;&#x440;&#x443;&#x441;? &#x414;&#x430;, &#x43d;&#x43e; &#x444;&#x430;&#x43b;&#x44c;&#x448;&#x438;&#x432;&#x44b;&#x439; &#x44d;&#x43a;&#x437;&#x435;&#x43c;&#x43f;&#x43b;&#x44f;&#x440;! </p>

<p>(Using quasiobsolete spelling for last word to include &#x44a;) &#x412; &#x447;&#x430;&#x449;&#x430;&#x445; &#x44e;&#x433;&#x430; &#x436;&#x438;&#x43b; &#x431;&#x44b; &#x446;&#x438;&#x442;&#x440;&#x443;&#x441;? &#x414;&#x430;, &#x43d;&#x43e; &#x444;&#x430;&#x43b;&#x44c;&#x448;&#x438;&#x432;&#x44b;&#x439; &#x44d;&#x43a;&#x437;&#x435;&#x43c;&#x43f;&#x43b;&#x44f;&#x440;&#x44a;! </p>

<p>&#x42d;&#x445;, &#x447;&#x443;&#x436;&#x430;&#x43a;! &#x41e;&#x431;&#x449;&#x438;&#x439; &#x441;&#x44a;&#x451;&#x43c; &#x446;&#x435;&#x43d; &#x448;&#x43b;&#x44f;&#x43f; (&#x44e;&#x444;&#x442;&#x44c;) &#x2014; &#x432;&#x434;&#x440;&#x44b;&#x437;&#x433;! </p>

<p>&#x42d;&#x43a;&#x441;-&#x433;&#x440;&#x430;&#x444;? &#x41f;&#x43b;&#x44e;&#x448; &#x438;&#x437;&#x44a;&#x44f;&#x442;. &#x411;&#x44c;&#x451;&#x43c; &#x447;&#x443;&#x436;&#x434;&#x44b;&#x439; &#x446;&#x435;&#x43d; &#x445;&#x432;&#x43e;&#x449;! </p>

<p>&#x421;&#x44a;&#x435;&#x448;&#x44c; &#x435;&#x449;&#x451; &#x44d;&#x442;&#x438;&#x445; &#x43c;&#x44f;&#x433;&#x43a;&#x438;&#x445; &#x444;&#x440;&#x430;&#x43d;&#x446;&#x443;&#x437;&#x441;&#x43a;&#x438;&#x445; &#x431;&#x443;&#x43b;&#x43e;&#x43a;, &#x434;&#x430; &#x432;&#x44b;&#x43f;&#x435;&#x439; &#x436;&#x435; &#x447;&#x430;&#x44e;. </p>

<p>&#x428;&#x438;&#x440;&#x43e;&#x43a;&#x430;&#x44f; &#x44d;&#x43b;&#x435;&#x43a;&#x442;&#x440;&#x438;&#x444;&#x438;&#x43a;&#x430;&#x446;&#x438;&#x44f; &#x44e;&#x436;&#x43d;&#x44b;&#x445; &#x433;&#x443;&#x431;&#x435;&#x440;&#x43d;&#x438;&#x439; &#x434;&#x430;&#x441;&#x442; &#x43c;&#x43e;&#x449;&#x43d;&#x44b;&#x439; &#x442;&#x43e;&#x43b;&#x447;&#x43e;&#x43a; &#x43f;&#x43e;&#x434;&#x44a;&#x451;&#x43c;&#x443; &#x441;&#x435;&#x43b;&#x44c;&#x441;&#x43a;&#x43e;&#x433;&#x43e; &#x445;&#x43e;&#x437;&#x44f;&#x439;&#x441;&#x442;&#x432;&#x430;. </p>

<h4>Serbian</h4>
<p>&#x409;&#x443;&#x431;&#x430;&#x437;&#x43d;&#x438; &#x444;&#x435;&#x45a;&#x435;&#x440;&#x45f;&#x438;&#x458;&#x430; &#x447;&#x430;&#x452;&#x430;&#x432;&#x43e;&#x433; &#x43b;&#x438;&#x446;&#x430; &#x445;&#x43e;&#x45b;&#x435; &#x434;&#x430; &#x43c;&#x438; &#x43f;&#x43e;&#x43a;&#x430;&#x436;&#x435; &#x448;&#x442;&#x43e;&#x441;. </p>

<p>Ljubazni fenjerd&#x17e;ija &#x10d;a&#x111;avog lica ho&#x107;e da mi poka&#x17e;e &#x161;tos. </p>

<h4>Slovene</h4>
<p>&#x160;erif bo za vajo spet kuhal doma&#x10d;e &#x17e;gance </p>

<p>Pi&#x161;kur mol&#x10d;e grabi fi&#x17e;ol z dna cezijeve hoste </p>

<h4>Spanish</h4>
<p>El veloz murci&#xe9;lago hind&#xfa; com&#xed;a feliz cardillo y kiwi. La cig&#xfc;e&#xf1;a tocaba el saxof&#xf3;n detr&#xe1;s del palenque de paja. </p>

<p>El ping&#xfc;ino Wenceslao hizo kil&#xf3;metros bajo exhaustiva lluvia y fr&#xed;o, a&#xf1;oraba a su querido cachorro. </p>

<p>Jovencillo emponzo&#xf1;ado de whisky: &#xa1;qu&#xe9; figurota exhibe! </p>

<p>Ese libro explica en su ep&#xed;grafe las haza&#xf1;as y aventuras de Don Quijote de la Mancha en Kuwait. </p>

<p>Queda gazpacho, fibra, l&#xe1;tex, jam&#xf3;n, kiwi y vi&#xf1;as. </p>

<p>Whisky bueno: &#xa1;excitad mi fr&#xe1;gil peque&#xf1;a vejez! </p>

<h4>Swedish</h4>
<p>Flygande b&#xe4;ckasiner s&#xf6;ka hwila p&#xe5; mjuka tuvor. </p>

<p>Yxskaftbud, ge v&#xe5;r wczonm&#xf6; iqhj&#xe4;lp. </p>

<h4>Ukrainian</h4>
<p>&#x427;&#x443;&#x454;&#x448; &#x457;&#x445;, &#x434;&#x43e;&#x446;&#x44e;, &#x433;&#x430;? &#x41a;&#x443;&#x43c;&#x435;&#x434;&#x43d;&#x430; &#x436; &#x442;&#x438;, &#x43f;&#x440;&#x43e;&#x449;&#x430;&#x439;&#x441;&#x44f; &#x431;&#x435;&#x437; &#x491;&#x43e;&#x43b;&#x44c;&#x444;&#x456;&#x432;! </p>

<p>&#x416;&#x435;&#x431;&#x440;&#x430;&#x43a;&#x443;&#x44e;&#x442;&#x44c; &#x444;&#x456;&#x43b;&#x43e;&#x441;&#x43e;&#x444;&#x438; &#x43f;&#x440;&#x438; &#x491;&#x430;&#x43d;&#x43a;&#x443; &#x446;&#x435;&#x440;&#x43a;&#x432;&#x438; &#x432; &#x413;&#x430;&#x434;&#x44f;&#x447;&#x456;, &#x449;&#x435; &#x439; &#x448;&#x430;&#x442;&#x440;&#x43e; &#x457;&#x445;&#x43d;&#x454; &#x43f;\'&#x44f;&#x43d;&#x435; &#x437;&#x43d;&#x430;&#x454;&#x43c;&#x43e;. </p>

<h4>Turkish (pangram)</h4>
<p>Pijamal&#x131; hasta ya&#x11f;&#x131;z &#x15f;of&#xf6;re &#xe7;abucak g&#xfc;vendi. </p>

<h4>Greek</h4>
<h5>Monotonic</h5>
<p>&#x3a0;&#x3ac;&#x3c4;&#x3b5;&#x3c1; &#x3b7;&#x3bc;&#x3ce;&#x3bd; &#x3bf; &#x3b5;&#x3bd; &#x3c4;&#x3bf;&#x3b9;&#x3c2; &#x3bf;&#x3c5;&#x3c1;&#x3b1;&#x3bd;&#x3bf;&#x3af;&#x3c2; &#x3b1;&#x3b3;&#x3b9;&#x3b1;&#x3c3;&#x3b8;&#x3ae;&#x3c4;&#x3c9; &#x3c4;&#x3bf; &#x3cc;&#x3bd;&#x3bf;&#x3bc;&#x3ac; &#x3c3;&#x3bf;&#x3c5;&#xb7; &#x3b5;&#x3bb;&#x3b8;&#x3ad;&#x3c4;&#x3c9; &#x3b7; &#x3b2;&#x3b1;&#x3c3;&#x3b9;&#x3bb;&#x3b5;&#x3af;&#x3b1; &#x3c3;&#x3bf;&#x3c5;&#xb7; &#x3b3;&#x3b5;&#x3bd;&#x3b7;&#x3b8;&#x3ae;&#x3c4;&#x3c9; &#x3c4;&#x3bf; &#x3b8;&#x3ad;&#x3bb;&#x3b7;&#x3bc;&#x3ac; &#x3c3;&#x3bf;&#x3c5;, &#x3c9;&#x3c2; &#x3b5;&#x3bd; &#x3bf;&#x3c5;&#x3c1;&#x3b1;&#x3bd;&#x3ce; &#x3ba;&#x3b1;&#x3b9; &#x3b5;&#x3c0;&#x3af; &#x3c4;&#x3b7;&#x3c2; &#x3b3;&#x3b7;&#x3c2;&#xb7; &#x3c4;&#x3bf;&#x3bd; &#x3ac;&#x3c1;&#x3c4;&#x3bf;&#x3bd; &#x3b7;&#x3bc;&#x3ce;&#x3bd; &#x3c4;&#x3bf;&#x3bd; &#x3b5;&#x3c0;&#x3b9;&#x3bf;&#x3cd;&#x3c3;&#x3b9;&#x3bf;&#x3bd; &#x3b4;&#x3bf;&#x3c2; &#x3b7;&#x3bc;&#x3af;&#x3bd; &#x3c3;&#x3ae;&#x3bc;&#x3b5;&#x3c1;&#x3bf;&#x3bd;&#xb7; &#x3ba;&#x3b1;&#x3b9; &#x3ac;&#x3c6;&#x3b5;&#x3c2; &#x3b7;&#x3bc;&#x3af;&#x3bd; &#x3c4;&#x3b1; &#x3bf;&#x3c6;&#x3b5;&#x3bb;&#x3ae;&#x3bc;&#x3b1;&#x3c4;&#x3b1; &#x3b7;&#x3bc;&#x3ce;&#x3bd;, &#x3c9;&#x3c2; &#x3ba;&#x3b1;&#x3b9; &#x3b7;&#x3bc;&#x3b5;&#x3af;&#x3c2; &#x3b1;&#x3c6;&#x3af;&#x3b5;&#x3bc;&#x3b5;&#x3bd; &#x3c4;&#x3bf;&#x3b9;&#x3c2; &#x3bf;&#x3c6;&#x3b5;&#x3b9;&#x3bb;&#x3ad;&#x3c4;&#x3b1;&#x3b9;&#x3c2; &#x3b7;&#x3bc;&#x3ce;&#x3bd;&#xb7; &#x3ba;&#x3b1;&#x3b9; &#x3bc;&#x3b7; &#x3b5;&#x3b9;&#x3c3;&#x3b5;&#x3bd;&#x3ad;&#x3b3;&#x3ba;&#x3b7;&#x3c2; &#x3b7;&#x3bc;&#x3ac;&#x3c2; &#x3b5;&#x3b9;&#x3c2; &#x3c0;&#x3b5;&#x3b9;&#x3c1;&#x3b1;&#x3c3;&#x3bc;&#x3cc;&#x3bd;, &#x3b1;&#x3bb;&#x3bb;&#x3ac; &#x3c1;&#x3cd;&#x3c3;&#x3b1;&#x3b9; &#x3b7;&#x3bc;&#x3ac;&#x3c2; &#x3b1;&#x3c0;&#x3cc; &#x3c4;&#x3bf;&#x3c5; &#x3c0;&#x3bf;&#x3bd;&#x3b7;&#x3c1;&#x3bf;&#x3cd;. &#x3b1;&#x3bc;&#x3ae;&#x3bd;. </p>

<h5>Polytonic</h5>
<p>&#x3a0;&#x3ac;&#x3c4;&#x3b5;&#x3c1; &#x1f21;&#x3bc;&#x1ff6;&#x3bd; &#x1f41; &#x1f10;&#x3bd; &#x3c4;&#x3bf;&#x1fd6;&#x3c2; &#x3bf;&#x1f50;&#x3c1;&#x3b1;&#x3bd;&#x3bf;&#x1fd6;&#x3c2; &#x1f01;&#x3b3;&#x3b9;&#x3b1;&#x3c3;&#x3b8;&#x3ae;&#x3c4;&#x3c9; &#x3c4;&#x1f78; &#x1f44;&#x3bd;&#x3bf;&#x3bc;&#x3ac; &#x3c3;&#x3bf;&#x3c5;&#xb7; &#x1f10;&#x3bb;&#x3b8;&#x3ad;&#x3c4;&#x3c9; &#x1f21; &#x3b2;&#x3b1;&#x3c3;&#x3b9;&#x3bb;&#x3b5;&#x3af;&#x3b1; &#x3c3;&#x3bf;&#x3c5;&#xb7; &#x3b3;&#x3b5;&#x3bd;&#x3b7;&#x3b8;&#x3ae;&#x3c4;&#x3c9; &#x3c4;&#x1f78; &#x3b8;&#x3ad;&#x3bb;&#x3b7;&#x3bc;&#x3ac; &#x3c3;&#x3bf;&#x3c5;, &#x1f61;&#x3c2; &#x1f10;&#x3bd; &#x3bf;&#x1f50;&#x3c1;&#x3b1;&#x3bd;&#x1ff7; &#x3ba;&#x3b1;&#x1f76; &#x1f10;&#x3c0;&#x1f76; &#x3c4;&#x1fc6;&#x3c2; &#x3b3;&#x1fc6;&#x3c2;&#xb7; &#x3c4;&#x1f78;&#x3bd; &#x1f04;&#x3c1;&#x3c4;&#x3bf;&#x3bd; &#x1f21;&#x3bc;&#x1ff6;&#x3bd; &#x3c4;&#x1f78;&#x3bd; &#x1f10;&#x3c0;&#x3b9;&#x3bf;&#x3cd;&#x3c3;&#x3b9;&#x3bf;&#x3bd; &#x3b4;&#x1f78;&#x3c2; &#x1f21;&#x3bc;&#x1fd6;&#x3bd; &#x3c3;&#x3ae;&#x3bc;&#x3b5;&#x3c1;&#x3bf;&#x3bd;&#xb7; &#x3ba;&#x3b1;&#x1f76; &#x1f04;&#x3c6;&#x3b5;&#x3c2; &#x1f21;&#x3bc;&#x1fd6;&#x3bd; &#x3c4;&#x1f70; &#x1f40;&#x3c6;&#x3b5;&#x3bb;&#x3ae;&#x3bc;&#x3b1;&#x3c4;&#x3b1; &#x1f21;&#x3bc;&#x1ff6;&#x3bd;, &#x1f61;&#x3c2; &#x3ba;&#x3b1;&#x1f76; &#x1f21;&#x3bc;&#x3b5;&#x1fd6;&#x3c2; &#x1f00;&#x3c6;&#x3af;&#x3b5;&#x3bc;&#x3b5;&#x3bd; &#x3c4;&#x3bf;&#x1fd6;&#x3c2; &#x1f40;&#x3c6;&#x3b5;&#x3b9;&#x3bb;&#x3ad;&#x3c4;&#x3b1;&#x3b9;&#x3c2; &#x1f21;&#x3bc;&#x1ff6;&#x3bd;&#xb7; &#x3ba;&#x3b1;&#x1f76; &#x3bc;&#x1f74; &#x3b5;&#x1f30;&#x3c3;&#x3b5;&#x3bd;&#x3ad;&#x3b3;&#x3ba;&#x1fc3;&#x3c2; &#x1f21;&#x3bc;&#x1fb6;&#x3c2; &#x3b5;&#x1f30;&#x3c2; &#x3c0;&#x3b5;&#x3b9;&#x3c1;&#x3b1;&#x3c3;&#x3bc;&#x3cc;&#x3bd;, &#x1f00;&#x3bb;&#x3bb;&#x1f70; &#x3c1;&#x1fe6;&#x3c3;&#x3b1;&#x3b9; &#x1f21;&#x3bc;&#x1fb6;&#x3c2; &#x1f00;&#x3c0;&#x1f78; &#x3c4;&#x3bf;&#x1fe6; &#x3c0;&#x3bf;&#x3bd;&#x3b7;&#x3c1;&#x3bf;&#x1fe6;. &#x1f00;&#x3bc;&#x3ae;&#x3bd;. </p>


<h3>Languages</h3>
<p>(The following are used for demonstration purposes only. Some of the following excerpts are taken from web pages from the BBC Foreign News just to show the script - I have no idea what they actually say!!)</p>

<h4>Latvian</h4>
<p>Latvijas instit&#x16b;ts veic konsultat&#x12b;vi koordin&#x113;jo&#x161;as funkcijas Latvijas starptautisk&#x101;s atpaz&#x12b;stam&#x12b;bas jom&#x101;;
gatavo un izplata pla&#x161;ai sabiedr&#x12b;bai pieejamu, svar&#x12b;gu pamatinform&#x101;ciju saturo&#x161;u, viegli izprotamu un iegaum&#x113;jamu, k&#x101; ar&#x12b; pozit&#x12b;vu iespaidu izraiso&#x161;u visp&#x101;r&#x113;ju pamatinform&#x101;ciju par Latviju, Latvijas dabu, sabiedr&#x12b;bu, kult&#x16b;ru un v&#x113;sturi;</p>

<h4>Azeri (az)</h4>
<p>Qaz k&#x259;m&#x259;rinin a&#xe7;&#x131;l&#x131;&#x15f;&#x131;nda &#x130;ran v&#x259; Erm&#x259;nistan&#x131;n prezidentl&#x259;ri i&#x15f;tirak edibl&#x259;r.</p>

<p>&#x130;ran qaz&#x131;n&#x131; Erm&#x259;nistana n&#x259;ql ed&#x259;c&#x259;k bu k&#x259;m&#x259;r Yerevan &#xfc;&#xe7;&#xfc;n x&#xfc;susi &#xf6;n&#x259;m da&#x15f;&#x131;y&#x131;r, bel&#x259; ki, b&#xf6;y&#xfc;k etnik az&#x259;rbaycanl&#x131; toplumuna malik &#x130;ran t&#x259;lat&#xfc;ml&#xfc; regionda &#xf6;z maraqlar&#x131;n&#x131; qorumaq &#xfc;&#xe7;&#xfc;n &#xe7;ox vaxt Erm&#x259;nistan&#x131;n m&#xfc;tt&#x259;fiqi kimi g&#xf6;r&#xfc;n&#xfc;b.</p>

<h4>Bulgarian</h4>
<p>&#x41f;&#x43e;&#x441;&#x43b;&#x435;&#x434;&#x43d;&#x438;&#x442;&#x435; &#x434;&#x43e;&#x43d;&#x430;&#x431;&#x43e;&#x440;&#x43d;&#x438;&#x446;&#x438; &#x432; &#x431;&#x44a;&#x43b;&#x433;&#x430;&#x440;&#x441;&#x43a;&#x430;&#x442;&#x430; &#x430;&#x440;&#x43c;&#x438;&#x44f; &#x449;&#x435; &#x441;&#x43b;&#x443;&#x436;&#x430;&#x442; 9 &#x43c;&#x435;&#x441;&#x435;&#x446;&#x430;, &#x43a;&#x430;&#x43a;&#x442;&#x43e; &#x43f;&#x43e;&#x441;&#x442;&#x430;&#x43d;&#x43e;&#x432;&#x44f;&#x432;&#x430; &#x437;&#x430;&#x43a;&#x43e;&#x43d;&#x430; 6 &#x43c;&#x435;&#x441;&#x435;&#x446;&#x430; &#x435; &#x441;&#x44a;&#x43a;&#x440;&#x430;&#x442;&#x435;&#x43d;&#x438;&#x44f;&#x442; &#x441;&#x440;&#x43e;&#x43a; &#x441;&#x430;&#x43c;&#x43e; &#x437;&#x430; &#x437;&#x430;&#x432;&#x44a;&#x440;&#x448;&#x438;&#x43b;&#x438;&#x442;&#x435; &#x432;&#x438;&#x441;&#x448;&#x435; &#x43e;&#x431;&#x440;&#x430;&#x437;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x435; - &#x442;&#x430;&#x43a;&#x430; &#x43c;&#x438;&#x43d;&#x438;&#x441;&#x442;&#x44a;&#x440; &#x412;&#x435;&#x441;&#x435;&#x43b;&#x438;&#x43d; &#x411;&#x43b;&#x438;&#x437;&#x43d;&#x430;&#x43a;&#x43e;&#x432; &#x43e;&#x442;&#x445;&#x432;&#x44a;&#x440;&#x43b;&#x438; &#x440;&#x430;&#x437;&#x43b;&#x438;&#x447;&#x43d;&#x438;&#x442;&#x435; &#x438;&#x43d;&#x442;&#x435;&#x440;&#x43f;&#x440;&#x435;&#x442;&#x430;&#x446;&#x438;&#x438; &#x432; &#x43f;&#x443;&#x431;&#x43b;&#x438;&#x447;&#x43d;&#x43e;&#x442;&#x43e; &#x43f;&#x440;&#x43e;&#x441;&#x442;&#x440;&#x430;&#x43d;&#x441;&#x442;&#x432;&#x43e; &#x43f;&#x43e; &#x442;&#x435;&#x43c;&#x430;&#x442;&#x430;. &#x41c;&#x438;&#x43d;&#x438;&#x441;&#x442;&#x44a;&#x440;&#x44a;&#x442; &#x43d;&#x430; &#x43e;&#x442;&#x431;&#x440;&#x430;&#x43d;&#x430;&#x442;&#x430; &#x440;&#x430;&#x437;&#x444;&#x43e;&#x440;&#x43c;&#x438;&#x440;&#x43e;&#x432;&#x430; &#x432; &#x41a;&#x430;&#x437;&#x430;&#x43d;&#x43b;&#x44a;&#x43a; &#x412;&#x442;&#x43e;&#x440;&#x430;&#x442;&#x430; &#x43d;&#x438; &#x440;&#x43e;&#x442;&#x430; &#x43e;&#x442; &#x410;&#x448;&#x440;&#x430;&#x444; &#x438; &#x412;&#x442;&#x43e;&#x440;&#x438; &#x43f;&#x435;&#x445;&#x43e;&#x442;&#x435;&#x43d; &#x432;&#x437;&#x432;&#x43e;&#x434;, &#x437;&#x430;&#x432;&#x44a;&#x440;&#x43d;&#x430;&#x43b; &#x441;&#x435; &#x43e;&#x442; &#x43c;&#x438;&#x440;&#x43e;&#x442;&#x432;&#x43e;&#x440;&#x447;&#x435;&#x441;&#x43a;&#x430; &#x43c;&#x438;&#x441;&#x438;&#x44f; &#x43e;&#x442; &#x411;&#x430;&#x43d;&#x44f; &#x41b;&#x443;&#x43a;&#x430; &#x432; &#x411;&#x43e;&#x441;&#x43d;&#x430; &#x438; &#x425;&#x435;&#x440;&#x446;&#x435;&#x433;&#x43e;&#x432;&#x438;&#x43d;&#x430;.</p>

<h4>Macedonian (mk)</h4>
<p>&#x411;&#x443;&#x448; &#x440;&#x435;&#x447;&#x435; &#x43e;&#x442;&#x438; &#x435; &#x441;&#x443;&#x448;&#x442;&#x438;&#x43d;&#x441;&#x43a;&#x438; &#x434;&#x430; &#x441;&#x435; &#x43e;&#x441;&#x438;&#x433;&#x443;&#x440;&#x438; &#x431;&#x435;&#x437;&#x431;&#x435;&#x434;&#x43d;&#x43e;&#x441;&#x442;&#x430; &#x43d;&#x430; &#x411;&#x430;&#x433;&#x434;&#x430;&#x434; &#x438; &#x434;&#x430; &#x441;&#x435; &#x43e;&#x431;&#x43d;&#x43e;&#x432;&#x438; &#x43d;&#x43e;&#x440;&#x43c;&#x430;&#x43b;&#x43d;&#x438;&#x43e;&#x442; &#x436;&#x438;&#x432;&#x43e;&#x442; &#x432;&#x43e; &#x43e;&#x441;&#x442;&#x430;&#x442;&#x43e;&#x43a;&#x43e;&#x442; &#x43e;&#x434; &#x437;&#x435;&#x43c;&#x458;&#x430;&#x442;&#x430;.</p>

<p>&#x41c;&#x438;&#x442;&#x440;&#x435;&#x432;&#x430; &#x458;&#x430; &#x43f;&#x440;&#x43e;&#x437;&#x432;&#x430; &#x432;&#x43b;&#x430;&#x434;&#x430;&#x442;&#x430; &#x437;&#x430; &#x438;&#x43d;&#x434;&#x43e;&#x43b;&#x435;&#x43d;&#x442;&#x435;&#x43d; &#x43e;&#x434;&#x43d;&#x43e;&#x441; &#x43a;&#x43e;&#x43d; &#x43e;&#x432;&#x430; &#x431;&#x438;&#x442;&#x43a;&#x430;&#x442;&#x430; &#x437;&#x430; &#x437;&#x430;&#x447;&#x443;&#x432;&#x438;&#x432;&#x430;&#x45a;&#x435; &#x43d;&#x430; &#x443;&#x441;&#x442;&#x430;&#x432;&#x43d;&#x43e;&#x442;&#x43e; &#x438;&#x43c;&#x435; &#x43d;&#x430; &#x437;&#x435;&#x43c;&#x458;&#x430;&#x442;&#x430;.</p>

<h4>Uzbek (uz)</h4>
<p>&#x418;&#x440;&#x43e;&#x49b;&#x43b;&#x438;&#x43a;&#x43b;&#x430;&#x440; &#x43e;&#x440;&#x430;&#x441;&#x438;&#x434;&#x430; &#x442;&#x443;&#x448;&#x43a;&#x443;&#x43d;&#x43b;&#x438;&#x43a; &#x43e;&#x440;&#x442;&#x438;&#x431; &#x431;&#x43e;&#x440;&#x430;&#x44f;&#x43f;&#x442;&#x438;</p>

<p>&#x418;&#x440;&#x43e;&#x49b;&#x434;&#x430; &#x45e;&#x442;&#x43a;&#x430;&#x437;&#x438;&#x43b;&#x433;&#x430;&#x43d; &#x441;&#x45e;&#x43d;&#x433;&#x433;&#x438; &#x436;&#x430;&#x43c;&#x43e;&#x430;&#x442;&#x447;&#x438;&#x43b;&#x438;&#x43a; &#x444;&#x438;&#x43a;&#x440;&#x438;&#x43d;&#x438; &#x45e;&#x440;&#x433;&#x430;&#x43d;&#x438;&#x448; &#x43d;&#x430;&#x442;&#x438;&#x436;&#x430;&#x43b;&#x430;&#x440;&#x438;&#x433;&#x430; &#x43a;&#x45e;&#x440;&#x430;, &#x43c;&#x430;&#x43c;&#x43b;&#x430;&#x43a;&#x430;&#x442; &#x43a;&#x435;&#x43b;&#x430;&#x436;&#x430;&#x433;&#x438; &#x431;&#x43e;&#x440;&#x430;&#x441;&#x438;&#x434;&#x430; &#x442;&#x443;&#x448;&#x43a;&#x443;&#x43d; &#x43a;&#x430;&#x439;&#x444;&#x438;&#x44f;&#x442;&#x434;&#x430; &#x431;&#x45e;&#x43b;&#x433;&#x430;&#x43d; &#x438;&#x440;&#x43e;&#x49b;&#x43b;&#x438;&#x43a;&#x43b;&#x430;&#x440; &#x441;&#x43e;&#x43d;&#x438; &#x442;&#x43e;&#x431;&#x43e;&#x440;&#x430; &#x43e;&#x440;&#x442;&#x438;&#x431; &#x431;&#x43e;&#x440;&#x43c;&#x43e;&#x49b;&#x434;&#x430;.</p>

<h4>Kyrgyz (ky)</h4>
<p>&#x41a;&#x430;&#x437;&#x430;&#x43a;&#x441;&#x442;&#x430;&#x43d;&#x434;&#x430; &#x430;&#x439;&#x44b;&#x43b; &#x442;&#x443;&#x440;&#x433;&#x443;&#x43d;&#x434;&#x430;&#x440;&#x44b; &#x443;&#x440;&#x443;&#x448;&#x430; &#x43a;&#x435;&#x442;&#x438;&#x43f; 3 &#x43a;&#x438;&#x448;&#x438; &#x43a;&#x430;&#x437;&#x430; &#x442;&#x430;&#x43f;&#x442;&#x44b;
&#x41a;&#x430;&#x437;&#x430;&#x43a;&#x441;&#x442;&#x430;&#x43d;&#x434;&#x44b;&#x43d; &#x410;&#x43b;&#x43c;&#x430;&#x442;&#x44b; &#x448;&#x430;&#x430;&#x440;&#x44b;&#x43d;&#x44b;&#x43d; &#x442;&#x443;&#x448;&#x443;&#x43d;&#x434;&#x430;&#x433;&#x44b; &#x430;&#x439;&#x44b;&#x43b;&#x434;&#x430; &#x44d;&#x43a;&#x438; &#x43a;&#x438;&#x448;&#x438; &#x43e;&#x440;&#x442;&#x43e;&#x441;&#x443;&#x43d;&#x434;&#x430;&#x433;&#x44b; &#x447;&#x430;&#x442;&#x430;&#x43a; &#x447;&#x43e;&#x4a3; &#x443;&#x440;&#x443;&#x448;&#x43a;&#x430; &#x430;&#x439;&#x43b;&#x430;&#x43d;&#x44b;&#x43f;, &#x430;&#x433;&#x430; &#x44d;&#x43b;&#x4af;&#x4af; &#x447;&#x430;&#x43a;&#x442;&#x44b; &#x43a;&#x438;&#x448;&#x438; &#x430;&#x440;&#x430;&#x43b;&#x430;&#x448;&#x43a;&#x430;&#x43d;.</p>



<h4>Albanian (sq)</h4>
<p>Nj&#xeb; anket&#xeb; sugjeron se irakian&#xeb;t kan&#xeb; nj&#xeb; pesimiz&#xeb;m n&#xeb; rritje p&#xeb;r t&#xeb; ardhmen e vendit t&#xeb; tyre.</p>

<p>Presidenti shqiptar Alfred Moisiu dekretoi t&#xeb; h&#xeb;n&#xeb;n ndryshimet e propozuara nga kryeministri Sali Berisha n&#xeb; kabinetin e tij, pas zgjedhjeve lokale.</p>


<h4>Vietnamese (vi)</h4>
<p>M&#xf4;&#x323;t kha&#x309;o sa&#x301;t m&#x1a1;&#x301;i cho bi&#xea;&#x301;t ng&#x1b0;&#x1a1;&#x300;i d&#xe2;n Iraq nga&#x300;y ca&#x300;ng ca&#x309;m th&#xe2;&#x301;y bi quan va&#x300; kh&#xf4;ng tin t&#x1b0;&#x1a1;&#x309;ng va&#x300;o chi&#x301;nh phu&#x309; cu&#x303;ng nh&#x1b0; li&#xea;n qu&#xe2;n</p>

<p>Nga &#x111;ang th&#x1b0;&#x323;c hi&#xea;&#x323;n chi&#xea;&#x301;n di&#x323;ch c&#x1b0;&#x301;u h&#xf4;&#x323; sau khi co&#x301; vu&#x323; n&#xf4;&#x309; khi&#x301; methane ta&#x323;i m&#xf4;&#x323;t mo&#x309; than &#x1a1;&#x309; Siberia la&#x300;m i&#x301;t nh&#xe2;&#x301;t 61 ng&#x1b0;&#x1a1;&#x300;i thi&#xea;&#x323;t ma&#x323;ng</p>

<h4>Thai (pangram)</h4>
<p>&#xe40;&#xe1b;&#xe47;&#xe19;&#xe21;&#xe19;&#xe38;&#xe29;&#xe22;&#xe4c;&#xe2a;&#xe38;&#xe14;&#xe1b;&#xe23;&#xe30;&#xe40;&#xe2a;&#xe23;&#xe34;&#xe10;&#xe40;&#xe25;&#xe34;&#xe28;&#xe04;&#xe38;&#xe13;&#xe04;&#xe48;&#xe32; &#xe01;&#xe27;&#xe48;&#xe32;&#xe1a;&#xe23;&#xe23;&#xe14;&#xe32;&#xe1d;&#xe39;&#xe07;&#xe2a;&#xe31;&#xe15;&#xe27;&#xe4c;&#xe40;&#xe14;&#xe23;&#xe31;&#xe08;&#xe09;&#xe32;&#xe19; &#xe08;&#xe07;&#xe1d;&#xe48;&#xe32;&#xe1f;&#xe31;&#xe19;&#xe1e;&#xe31;&#xe12;&#xe19;&#xe32;&#xe27;&#xe34;&#xe0a;&#xe32;&#xe01;&#xe32;&#xe23; &#xe2d;&#xe22;&#xe48;&#xe32;&#xe25;&#xe49;&#xe32;&#xe07;&#xe1c;&#xe25;&#xe32;&#xe0d;&#xe24;&#xe45;&#xe40;&#xe02;&#xe48;&#xe19;&#xe06;&#xe48;&#xe32;&#xe1a;&#xe35;&#xe11;&#xe32;&#xe43;&#xe04;&#xe23; &#xe44;&#xe21;&#xe48;&#xe16;&#xe37;&#xe2d;&#xe42;&#xe17;&#xe29;&#xe42;&#xe01;&#xe23;&#xe18;&#xe41;&#xe0a;&#xe48;&#xe07;&#xe0b;&#xe31;&#xe14;&#xe2e;&#xe36;&#xe14;&#xe2e;&#xe31;&#xe14;&#xe14;&#xe48;&#xe32; &#xe2b;&#xe31;&#xe14;&#xe2d;&#xe20;&#xe31;&#xe22;&#xe40;&#xe2b;&#xe21;&#xe37;&#xe2d;&#xe19;&#xe01;&#xe35;&#xe2c;&#xe32;&#xe2d;&#xe31;&#xe0a;&#xe0c;&#xe32;&#xe2a;&#xe31;&#xe22; &#xe1b;&#xe0f;&#xe34;&#xe1a;&#xe31;&#xe15;&#xe34;&#xe1b;&#xe23;&#xe30;&#xe1e;&#xe24;&#xe15;&#xe34;&#xe01;&#xe0e;&#xe01;&#xe33;&#xe2b;&#xe19;&#xe14;&#xe43;&#xe08; &#xe1e;&#xe39;&#xe14;&#xe08;&#xe32;&#xe43;&#xe2b;&#xe49;&#xe08;&#xe4a;&#xe30;&#xe46; &#xe08;&#xe4b;&#xe32; &#xe19;&#xe48;&#xe32;&#xe1f;&#xe31;&#xe07;&#xe40;&#xe2d;&#xe22;&#xe2f; </p>


<!-- RTL LANGUAGES -->
<div style="text-align: right;">

<h4>Hebrew (pangram)</h4>
<p>&#x5d3;&#x5d2; &#x5e1;&#x5e7;&#x5e8;&#x5df; &#x5e9;&#x5d8; &#x5d1;&#x5d9;&#x5dd; &#x5de;&#x5d0;&#x5d5;&#x5db;&#x5d6;&#x5d1; &#x5d5;&#x5dc;&#x5e4;&#x5ea;&#x5e2; &#x5de;&#x5e6;&#x5d0; &#x5d7;&#x5d1;&#x5e8;&#x5d4; </p>

<p>&#x5d0;&#x5d5; &#x5d4;&#x5e0;&#x5e1;&#x5d4; &#x5d0;&#x5dc;&#x5d4;&#x5d9;&#x5dd;, &#x5dc;&#x5d1;&#x5d5;&#x5d0; &#x5dc;&#x5e7;&#x5d7;&#x5ea; &#x5dc;&#x5d5; &#x5d2;&#x5d5;&#x5d9; &#x5de;&#x5e7;&#x5e8;&#x5d1; &#x5d2;&#x5d5;&#x5d9;, &#x5d1;&#x5de;&#x5e1;&#x5ea; &#x5d1;&#x5d0;&#x5ea;&#x5ea; &#x5d5;&#x5d1;&#x5de;&#x5d5;&#x5e4;&#x5ea;&#x5d9;&#x5dd; &#x5d5;&#x5d1;&#x5de;&#x5dc;&#x5d7;&#x5de;&#x5d4; &#x5d5;&#x5d1;&#x5d9;&#x5d3; &#x5d7;&#x5d6;&#x5e7;&#x5d4; &#x5d5;&#x5d1;&#x5d6;&#x5e8;&#x5d5;&#x5e2; &#x5e0;&#x5d8;&#x5d5;&#x5d9;&#x5d4;, &#x5d5;&#x5d1;&#x5de;&#x5d5;&#x5e8;&#x5d0;&#x5d9;&#x5dd; &#x5d2;&#x5d3;&#x5dc;&#x5d9;&#x5dd;: &#x5db;&#x5db;&#x5dc; &#x5d0;&#x5e9;&#x5e8;-&#x5e2;&#x5e9;&#x5d4; &#x5dc;&#x5db;&#x5dd; &#x5d9;&#x5d4;&#x5d5;&#x5d4; &#x5d0;&#x5dc;&#x5d4;&#x5d9;&#x5db;&#x5dd;, &#x5d1;&#x5de;&#x5e6;&#x5e8;&#x5d9;&#x5dd;--&#x5dc;&#x5e2;&#x5d9;&#x5e0;&#x5d9;&#x5da; </p>




<h4>Arabic</h4>
<p>&#x642;&#x627;&#x644; &#x627;&#x644;&#x631;&#x626;&#x64a;&#x633; &#x627;&#x644;&#x627;&#x645;&#x631;&#x64a;&#x643;&#x64a; &#x62c;&#x648;&#x631;&#x62c; &#x628;&#x648;&#x634; &#x641;&#x64a; &#x62d;&#x62f;&#x64a;&#x62b; &#x645;&#x62a;&#x644;&#x641;&#x632; &#x641;&#x64a; &#x627;&#x644;&#x630;&#x643;&#x631;&#x649; &#x627;&#x644;&#x631;&#x627;&#x628;&#x639;&#x629; &#x644;&#x644;&#x63a;&#x632;&#x648; &#x627;&#x644;&#x627;&#x645;&#x631;&#x64a;&#x643;&#x64a; &#x644;&#x644;&#x639;&#x631;&#x627;&#x642; &#x627;&#x646; &#x627;&#x644;&#x627;&#x648;&#x644;&#x648;&#x64a;&#x629; &#x62d;&#x627;&#x644;&#x64a;&#x627; &#x644;&#x627;&#x639;&#x627;&#x62f;&#x629; &#x627;&#x644;&#x627;&#x645;&#x646; &#x644;&#x644;&#x639;&#x631;&#x627;&#x642;.</p>

<p>&#x647;&#x644; &#x633;&#x62a;&#x633;&#x641;&#x631; &#x627;&#x644;&#x62c;&#x647;&#x648;&#x62f; &#x627;&#x644;&#x62f;&#x628;&#x644;&#x648;&#x645;&#x627;&#x633;&#x64a;&#x629; &#x627;&#x644;&#x62c;&#x627;&#x631;&#x64a;&#x629; &#x639;&#x646; &#x62d;&#x644;&#x648;&#x644;&#x61f; &#x648;&#x643;&#x64a;&#x641; &#x62a;&#x646;&#x638;&#x631; &#x644;&#x644;&#x627;&#x62a;&#x647;&#x627;&#x645;&#x627;&#x62a; &#x644;&#x628;&#x639;&#x636; &#x647;&#x630;&#x647; &#x627;&#x644;&#x62f;&#x648;&#x644; &#x628;&#x627;&#x644;&#x62a;&#x62f;&#x62e;&#x644; &#x641;&#x64a; &#x627;&#x644;&#x634;&#x623;&#x646; &#x627;&#x644;&#x639;&#x631;&#x627;&#x642;&#x64a;&#x60c; &#x648;&#x627;&#x644;&#x62a;&#x648;&#x631;&#x637; &#x641;&#x64a; &#x62f;&#x639;&#x645; &#x639;&#x645;&#x644;&#x64a;&#x627;&#x62a; &#x627;&#x644;&#x639;&#x646;&#x641;&#x61f; &#x648;&#x627;&#x644;&#x649; &#x627;&#x64a; &#x645;&#x62f;&#x649; &#x64a;&#x628;&#x62f;&#x648; &#x627;&#x644;&#x648;&#x636;&#x639; &#x641;&#x64a; &#x627;&#x644;&#x639;&#x631;&#x627;&#x642; &#x627;&#x646;&#x639;&#x643;&#x627;&#x633;&#x627; &#x644;&#x644;&#x635;&#x631;&#x627;&#x639;&#x627;&#x62a; &#x627;&#x644;&#x625;&#x642;&#x644;&#x64a;&#x645;&#x64a;&#x629; &#x641;&#x64a; &#x627;&#x644;&#x645;&#x646;&#x637;&#x642;&#x629;&#x61f;</p>

<h4>Persian / Farsi</h4>
<p>&#x645;&#x62d;&#x645;&#x62f; &#x627;&#x644;&#x628;&#x631;&#x627;&#x62f;&#x639;&#x6cc; &#x631;&#x626;&#x64a;&#x633; &#x622;&#x698;&#x627;&#x646;&#x633; &#x628;&#x64a;&#x646; &#x627;&#x644;&#x645;&#x644;&#x644;&#x6cc; &#x627;&#x646;&#x631;&#x698;&#x6cc; &#x627;&#x62a;&#x645;&#x6cc; &#x67e;&#x64a;&#x634;&#x646;&#x647;&#x627;&#x62f; &#x6a9;&#x631;&#x62f;&#x647; &#x627;&#x633;&#x62a; &#x62a;&#x647;&#x631;&#x627;&#x646; &#x628;&#x631;&#x646;&#x627;&#x645;&#x647; &#x62c;&#x646;&#x62c;&#x627;&#x644;&#x6cc; &#x63a;&#x646;&#x6cc; &#x633;&#x627;&#x632;&#x6cc; &#x627;&#x648;&#x631;&#x627;&#x646;&#x64a;&#x648;&#x645; &#x631;&#x627; &#x645;&#x62a;&#x648;&#x642;&#x641; &#x6a9;&#x646;&#x62f; &#x648; &#x63a;&#x631;&#x628; &#x646;&#x64a;&#x632; &#x627;&#x62c;&#x631;&#x627;&#x6cc; &#x62a;&#x62d;&#x631;&#x64a;&#x645; &#x647;&#x627;&#x6cc; &#x62a;&#x646;&#x628;&#x64a;&#x647;&#x6cc; &#x645;&#x648;&#x631;&#x62f; &#x62a;&#x627;&#x626;&#x64a;&#x62f; &#x633;&#x627;&#x632;&#x645;&#x627;&#x646; &#x645;&#x644;&#x644; &#x645;&#x62a;&#x62d;&#x62f; &#x631;&#x627; &#x628;&#x647; &#x62a;&#x639;&#x648;&#x64a;&#x642; &#x628;&#x64a;&#x627;&#x646;&#x62f;&#x627;&#x632;&#x62f;.</p>



<h4>Urdu</h4>
<p>&#x62a;&#x645;&#x627;&#x645; &#x627;&#x646;&#x633;&#x627;&#x646; &#x622;&#x632;&#x627;&#x62f; &#x627;&#x648;&#x631; &#x62d;&#x642;&#x648;&#x642; &#x648; &#x639;&#x632;&#x62a; &#x6a9;&#x6d2; &#x627;&#x639;&#x62a;&#x628;&#x627;&#x631; &#x633;&#x6d2; &#x628;&#x631;&#x627;&#x628;&#x631; &#x67e;&#x6cc;&#x62f;&#x627; &#x6c1;&#x648;&#x6d3; &#x6c1;&#x6cc;&#x6ba;&#x6d4; &#x627;&#x646;&#x6c1;&#x6cc;&#x6ba; &#x636;&#x645;&#x6cc;&#x631; &#x627;&#x648;&#x631; &#x639;&#x642;&#x644; &#x648;&#x62f;&#x6cc;&#x639;&#x62a; &#x6c1;&#x648;&#x626;&#x6cc; &#x6c1;&#x6cc;&#x6d4; &#x627;&#x633;&#x644;&#x6d3; &#x627;&#x646;&#x6c1;&#x6cc;&#x6ba; &#x627;&#x6cc;&#x6a9; &#x62f;&#x648;&#x633;&#x631;&#x6d2; &#x6a9;&#x6d2; &#x633;&#x627;&#x62a;&#x6be; &#x628;&#x6be;&#x627;&#x626;&#x6cc; &#x686;&#x627;&#x631;&#x6d2; &#x6a9;&#x627; &#x633;&#x644;&#x648;&#x6a9; &#x6a9;&#x631;&#x646;&#x627; &#x686;&#x627;&#x6c1;&#x6cc;&#x6d3;&#x6d4;
</p>

<h4>Pashto (ps)</h4>
<p>&#x67e;&#x647; &#x6a9;&#x627;&#x628;&#x644; &#x627;&#x648; &#x6a9;&#x646;&#x62f;&#x647;&#x627;&#x631; &#x6a9;&#x6d0; &#x62f;&#x648;&#x648; &#x681;&#x627;&#x646;&#x645;&#x631;&#x6af;&#x648; &#x628;&#x631;&#x64a;&#x62f;&#x648;&#x646;&#x648; &#x644;&#x696; &#x62a;&#x631; &#x644;&#x696;&#x647; &#x64a;&#x648; &#x645;&#x627;&#x634;&#x648;&#x645; &#x648;&#x698;&#x644;&#x649; &#x627;&#x648; &#x627;&#x62a;&#x647; &#x62a;&#x646;&#x647; &#x646;&#x648;&#x631; &#x649;&#x6d0; &#x67c;&#x67e;&#x64a;&#x627;&#x646; &#x6a9;&#x693;&#x64a;.
</p>


<h4>Sindhi (sd)</h4>
<p>
&#x648;&#x627;&#x634;&#x646;&#x6af;&#x67d;&#x646; (&#x645; &#x68a;) &#x622;&#x645;&#x631;&#x64a;&#x6aa;&#x627; &#x686;&#x64a;&#x648; &#x622;&#x647;&#x64a; &#x62a;&#x647; &#x6aa;&#x64a;&#x631;&#x64a; &#x644;&#x648;&#x6af;&#x631;&#x628;&#x644; &#x62a;&#x64a; &#x67e;&#x627;&#x6aa; &#x641;&#x648;&#x62c; &#x62c;&#x64a; &#x62a;&#x62d;&#x641;&#x638;&#x627;&#x62a; &#x633;&#x627;&#x646; &#x67e;&#x627;&#x6aa;&#x633;&#x62a;&#x627;&#x646; &#x6fe; &#x62c;&#x645;&#x647;&#x648;&#x631;&#x64a; &#x637;&#x648;&#x631; &#x622;&#x64a;&#x644; &#x632;&#x631;&#x62f;&#x627;&#x631;&#x64a; &#x62c;&#x64a; &#x62d;&#x6aa;&#x648;&#x645;&#x62a; &#x6a9;&#x64a; &#x6aa;&#x648;&#x628;&#x647; &#x62e;&#x637;&#x631;&#x648; &#x646;&#x627;&#x647;&#x64a;&#x60c; &#x627;&#x646; &#x633;&#x648;&#x627;&#x644; &#x62a;&#x64a; &#x62a;&#x64a; &#x6aa;&#x64a;&#x631;&#x64a; &#x644;&#x648;&#x6af;&#x631;&#x628;&#x644; &#x6fe; &#x67e;&#x627;&#x6aa;&#x633;&#x62a;&#x627;&#x646; &#x6a9;&#x64a; &#x63a;&#x64a;&#x631; &#x645;&#x634;&#x631;&#x648;&#x637; &#x627;&#x645;&#x62f;&#x627;&#x62f; &#x68f;&#x64a;&#x6bb; &#x62c;&#x64a; &#x6b3;&#x627;&#x644;&#x647;&#x647; &#x6aa;&#x626;&#x64a; &#x648;&#x626;&#x64a; &#x622;&#x647;&#x64a;&#x60c; &#x62c;&#x68f;&#x647;&#x646; &#x62a;&#x647; &#x641;&#x648;&#x62c;&#x64a; &#x627;&#x645;&#x62f;&#x627;&#x62f; &#x62a;&#x64a; &#x634;&#x631;&#x637; &#x644;&#x627;&#x6b3;&#x648; &#x6aa;&#x64a;&#x627;
</p>

</div>
<!-- END RTL LANGUAGES -->

<h3>Indic Scripts</h3>

<h4>
Malayalam
</h4>
<p>&#xd38;&#xd02;&#xd38;&#xd4d;&#xd25;&#xd3e;&#xd28;&#xd24;&#xd4d;&#xd24;&#xd4d; &#xd30;&#xd3e;&#xd37;&#xd4d;&#xd1f;&#xd4d;&#xd30;&#xd40;&#xd2f; &#xd2a;&#xd41;&#xd15;&#xd2e;&#xd31; &#xd38;&#xd43;&#xd37;&#xd4d;&#xd1f;&#xd3f;&#xd15;&#xd4d;&#xd15;&#xd3e;&#xd28;&#xd3e;&#xd23;&#xd4d; &#xd35;&#xd4b;&#xd1f;&#xd4d;&#xd1f;&#xd30;&#xd4d;&#x200d;&#xd2a;&#xd1f;&#xd4d;&#xd1f;&#xd3f;&#xd15; &#xd35;&#xd3f;&#xd35;&#xd3e;&#xd26;&#xd24;&#xd4d;&#xd24;&#xd3f;&#xd32;&#xd42;&#xd1f;&#xd46; &#xd15;&#xd4b;&#xd23;&#xd4d;&#x200d;&#xd17;&#xd4d;&#xd30;&#xd38;&#xd4d; &#xd36;&#xd4d;&#xd30;&#xd2e;&#xd3f;&#xd15;&#xd4d;&#xd15;&#xd41;&#xd28;&#xd4d;&#xd28;&#xd24;&#xd46;&#xd28;&#xd4d;&#xd28;&#xd4d; &#xd38;&#xd3f;&#xd2a;&#xd3f;&#x200c;&#xd0e;&#xd02; &#xd38;&#xd02;&#xd38;&#xd4d;&#xd25;&#xd3e;&#xd28; &#xd38;&#xd46;&#xd15;&#xd4d;&#xd30;&#xd1f;&#xd4d;&#xd1f;&#xd31;&#xd3f; &#xd2a;&#xd3f;&#xd23;&#xd31;&#xd3e;&#xd2f;&#xd3f; &#xd35;&#xd3f;&#xd1c;&#xd2f;&#xd28;&#xd4d;&#x200d; &#xd15;&#xd41;&#xd31;&#xd4d;&#xd31;&#xd2a;&#xd4d;&#xd2a;&#xd46;&#xd1f;&#xd41;&#xd24;&#xd4d;&#xd24;&#xd3f;&#x0964; &#xd09;&#xd26;&#xd4d;&#xd2f;&#xd4b;&#xd17;&#xd38;&#xd4d;&#xd25;&#xd30;&#xd46; &#xd2d;&#xd40;&#xd37;&#xd23;&#xd3f;&#xd2a;&#xd4d;&#xd2a;&#xd46;&#xd1f;&#xd41;&#xd24;&#xd4d;&#xd24;&#xd3f; &#xd35;&#xd30;&#xd41;&#xd24;&#xd3f;&#xd2f;&#xd3f;&#xd32;&#xd4d;&#x200d; &#xd28;&#xd3f;&#xd30;&#xd4d;&#x200d;&#xd24;&#xd4d;&#xd24;&#xd3e;&#xd28;&#xd3e;&#xd23;&#xd4d; &#xd35;&#xd2f;&#xd32;&#xd3e;&#xd30;&#xd4d;&#x200d; &#xd30;&#xd35;&#xd3f; &#xd09;&#xd33;&#xd4d;&#x200d;&#xd2a;&#xd4d;&#xd2a;&#xd46;&#xd1f;&#xd46;&#xd2f;&#xd41;&#xd33;&#xd4d;&#xd33;&#xd35;&#xd30;&#xd4d;&#x200d; &#xd36;&#xd4d;&#xd30;&#xd2e;&#xd3f;&#xd15;&#xd4d;&#xd15;&#xd41;&#xd28;&#xd4d;&#xd28;&#xd24;&#xd46;&#xd28;&#xd4d;&#xd28;&#xd41;&#xd02; &#xd2a;&#xd3f;&#xd23;&#xd31;&#xd3e;&#x200d;&#xd2f;&#xd3f; &#xd2a;&#xd4d;&#xd30;&#xd38;&#xd4d;&#xd24;&#xd3e;&#xd35;&#xd28;&#xd2f;&#xd3f;&#xd32;&#xd4d;&#x200d; &#xd06;&#xd30;&#xd4b;&#xd2a;&#xd3f;&#xd1a;&#xd4d;&#xd1a;&#xd41;&#x0964;
</p>

<h4>Kannada</h4>
<p>
&#xca4;&#xcae;&#xccd;&#xcae;&#xca6;&#xcc7; &#xc95;&#xcc1;&#xc9f;&#xcc1;&#xc82;&#xcac;&#xca6; &#xcaf;&#xcc1;&#xcb5;&#xca4;&#xcbf;&#xcaf;&#xcca;&#xcac;&#xccd;&#xcac;&#xcb3;&#xca8;&#xccd;&#xca8;&#xcc1; &#xcb8;&#xca4;&#xca4; &#xcb9;&#xcb2;&#xcb5;&#xcbe;&#xcb0;&#xcc1; &#xcb5;&#xcb0;&#xccd;&#xcb7; &#xcad;&#xccb;&#xc97;&#xcbf;&#xcb8;&#xcbf;&#xca6; &#xcad;&#xcbe;&#xcb0;&#xca4;&#xcc0;&#xcaf; &#xcae;&#xcc2;&#xcb2;&#xca6; &#xcae;&#xcc2;&#xcb5;&#xcb0;&#xcc1; &#xca6;&#xcc1;&#xcb0;&#xcc1;&#xcb3; &#xcb8;&#xc82;&#xcac;&#xc82;&#xca7;&#xcbf;&#xc95;&#xcb0;&#xcc1; &#xc85;&#xcaa;&#xcb0;&#xcbe;&#xca7;&#xcbf;&#xc97;&#xcb3;&#xcc6;&#xc82;&#xca6;&#xcc1; &#xcb8;&#xcbe;&#xcac;&#xcc0;&#xca4;&#xcbe;&#xc97;&#xcbf;&#xca6;&#xccd;&#xca6;&#xcc1;, &#xc87;&#xc82;&#xc97;&#xccd;&#xcb2;&#xcc6;&#xc82;&#xca1;&#xccd; &#xca8;&#xccd;&#xcaf;&#xcbe;&#xcaf;&#xcbe;&#xcb2;&#xcaf;&#xcb5;&#xcc1; &#xca6;&#xcc0;&#xcb0;&#xccd;&#xc98;&#xcbe;&#xcb5;&#xca7;&#xcbf; &#xc95;&#xca0;&#xcbf;&#xca3; &#xcb6;&#xcbf;&#xc95;&#xccd;&#xcb7;&#xcc6; &#xcb5;&#xcbf;&#xca7;&#xcbf;&#xcb8;&#xcbf;&#xca6;&#xcc6;.
</p>

<h4>Telegu</h4>
<p>&#xc06;&#xc17;&#xc4d;&#xc28;&#xc47;&#xc2f; &#xc07;&#xc30;&#xc3e;&#xc28;&#xc4d;&#x200c;&#xc32;&#xc4b; &#xc06;&#xc26;&#xc3f;&#xc35;&#xc3e;&#xc30;&#xc02; &#xc28;&#xc3e;&#xc21;&#xc41; &#xc13; &#xc06;&#xc24;&#xc4d;&#xc2e;&#xc3e;&#xc39;&#xc41;&#xc24;&#xc3f; &#xc26;&#xc3e;&#xc21;&#xc3f; &#xc1c;&#xc30;&#xc17;&#xc21;&#xc02;&#xc24;&#xc4b; &#xc07;&#xc30;&#xc35;&#xc48; &#xc2e;&#xc02;&#xc26;&#xc3f; &#xc2e;&#xc43;&#xc24;&#xc3f; &#xc1a;&#xc46;&#xc02;&#xc26;&#xc3e;&#xc30;&#xc41;.
<br />

&#xc06;&#xc17;&#xc4d;&#xc28;&#xc47;&#xc2f; &#xc07;&#xc30;&#xc3e;&#xc28;&#xc4d;&#x200c;&#xc32;&#xc4b; &#xc06;&#xc24;&#xc4d;&#xc2e;&#xc3e;&#xc39;&#xc41;&#xc24;&#xc3f; &#xc26;&#xc3e;&#xc21;&#xc3f; &#xc1c;&#xc30;&#xc17;&#xc21;&#xc02;&#xc24;&#xc4b; &#xc10;&#xc26;&#xc41;&#xc17;&#xc41;&#xc30;&#xc41; &#xc0e;&#xc32;&#xc3f;&#xc1f;&#xc4d; &#xc30;&#xc46;&#xc35;&#xc32;&#xc4d;&#xc2f;&#xc42;&#xc37;&#xc28;&#xc30;&#xc40; &#xc17;&#xc3e;&#xc30;&#xc4d;&#xc21;&#xc4d;&#x200c;&#xc32;&#xc24;&#xc4b; &#xc38;&#xc39;&#xc3e; &#xc2a;&#xc4d;&#xc30;&#xc2e;&#xc41;&#xc16; &#xc15;&#xc2e;&#xc3e;&#xc02;&#xc21;&#xc30;&#xc4d;&#x200c;&#xc32;&#xc24;&#xc4b;&#xc38;&#xc39;&#xc3e; &#xc2e;&#xc4a;&#xc24;&#xc4d;&#xc24;&#xc02; &#xc07;&#xc30;&#xc35;&#xc48; &#xc2e;&#xc02;&#xc26;&#xc3f; &#xc2e;&#xc43;&#xc24;&#xc3f; &#xc1a;&#xc46;&#xc02;&#xc26;&#xc3f;&#xc28;&#xc1f;&#xc4d;&#xc32;&#xc41; &#xc07;&#xc30;&#xc3e;&#xc28;&#xc4d; &#xc32;&#xc4b;&#xc15;&#xc4d;&#x200c;&#xc38;&#xc2d; &#xc38;&#xc4d;&#xc2a;&#xc40;&#xc15;&#xc30;&#xc4d; &#xc05;&#xc32;&#xc40; &#xc32;&#xc3e;&#xc30;&#xc3f;&#xc1c;&#xc3e;&#xc28;&#xc40; &#xc24;&#xc46;&#xc32;&#xc3f;&#xc2a;&#xc3e;&#xc30;&#xc41;.
</p>



<h4>Tamil (ta)</h4>
<p>&#xb87;&#xbb0;&#xbbe;&#xb95;&#xbcd;&#xb95;&#xbbf;&#xbaf; &#xbae;&#xb95;&#xbcd;&#xb95;&#xbb3;&#xbcd; &#xb85;&#xbb5;&#xba8;&#xbae;&#xbcd;&#xbaa;&#xbbf;&#xb95;&#xbcd;&#xb95;&#xbc8;&#xbaf;&#xbc1;&#xb9f;&#xba9;&#xbcd; &#xb87;&#xbb0;&#xbc1;&#xbaa;&#xbcd;&#xbaa;&#xba4;&#xbbe;&#xb95;&#xbb5;&#xbc1;&#xbae;&#xbcd;, &#xbb7;&#xbbf;&#xbaf;&#xbbe; &#xbae;&#xbb1;&#xbcd;&#xbb1;&#xbc1;&#xbae;&#xbcd; &#xb9a;&#xbc1;&#xba9;&#xbbf;&#xb95;&#xbcd;&#xb95;&#xbb3;&#xbcd; &#xbae;&#xbc1;&#xbb0;&#xba3;&#xbcd;&#xbaa;&#xb9f;&#xbcd;&#xb9f; &#xb95;&#xbb0;&#xbc1;&#xba4;&#xbcd;&#xba4;&#xbc1;&#xb95;&#xbcd;&#xb95;&#xbb3;&#xbc1;&#xb9f;&#xba9;&#xbcd; &#xba4;&#xbc1;&#xbb0;&#xbc1;&#xbb5;&#xbaa;&#xbcd;&#xbaa;&#xb9f;&#xbcd;&#xb9f; &#xba8;&#xbbf;&#xbb2;&#xbc8;&#xbaf;&#xbbf;&#xbb2;&#xbcd; &#xb87;&#xbb0;&#xbc1;&#xbaa;&#xbcd;&#xbaa;&#xba4;&#xbbe;&#xb95;&#xbb5;&#xbc1;&#xbae;&#xbcd; &#xb95;&#xbb0;&#xbc1;&#xba4;&#xbcd;&#xba4;&#xbc1;&#xb95;&#xbcd; &#xb95;&#xba3;&#xbbf;&#xbaa;&#xbcd;&#xbaa;&#xbc1; &#xb92;&#xba9;&#xbcd;&#xbb1;&#xbc1; &#xb95;&#xbc2;&#xbb1;&#xbc1;&#xb95;&#xbbf;&#xbb1;&#xba4;&#xbc1;.</p>


<h4>Oriya</h4>
<p>&#xb13;&#xb21;&#xb3c;&#xb3f;&#xb06; &#xb09;&#xb07;&#xb15;&#xb3f;&#xb2a;&#xb47;&#xb21;&#xb3f;&#xb06; &#xb06;&#xb2a;&#xb23;&#xb19;&#xb4d;&#xb15;&#xb41; &#xb38;&#xb4d;&#xb2c;&#xb3e;&#xb17;&#xb24; &#xb15;&#xb30;&#xb41;&#xb1b;&#xb3f;&#x964; &#xb0f;&#xb39;&#xb3f; &#xb09;&#xb28;&#xb4d;&#xb2e;&#xb41;&#xb15;&#xb4d;&#xb24; &#xb1c;&#xb4d;&#xb1e;&#xb3e;&#xb28;&#xb15;&#xb4b;&#xb37;&#xb1f;&#xb3f; &#xb07;&#xb23;&#xb4d;&#xb1f;&#xb30;&#xb28;&#xb47;&#xb1f; &#xb09;&#xb2a;&#xb30;&#xb47; &#xb06;&#xb27;&#xb3e;&#xb30;&#xb3f;&#xb24; &#xb0f;&#xb2c;&#xb02; &#xb0f;&#xb39;&#xb3e; &#xb2c;&#xb3f;&#xb36;&#xb4d;&#xb2c;&#xb30; &#xb6b;&#xb66;&#xb1f;&#xb3f; &#xb2d;&#xb3e;&#xb37;&#xb3e;&#xb30;&#xb47; &#xb09;&#xb2a;&#xb32;&#xb2c;&#xb4d;&#xb27; &#x964; &#xb0f;&#xb39;&#xb3e;&#xb15;&#xb41; &#xb06;&#xb2a;&#xb23; &#xb2e;&#xb27;&#xb4d;&#xb5f; &#xb2c;&#xb30;&#xb4d;&#xb26;&#xb4d;&#xb27;&#xb3f;&#xb24; &#xb13; &#xb2a;&#xb30;&#xb3f;&#xb2c;&#xb30;&#xb4d;&#xb24;&#xb3f;&#xb24; &#xb15;&#xb30;&#xb3f;&#xb2a;&#xb3e;&#xb30;&#xb3f;&#xb2c;&#xb47; &#xb0f;&#xb2c;&#xb02; &#xb0f;&#xb39;&#xb3e;&#xb15;&#xb41; &#xb09;&#xb28;&#xb4d;&#xb28;&#xb24; &#xb15;&#xb30;&#xb3f;&#xb2c;&#xb3e; &#xb2a;&#xb3e;&#xb07;&#xb01; &#xb28;&#xb3f;&#xb1c;&#xb30; &#xb05;&#xb2c;&#xb26;&#xb3e;&#xb28; &#xb26;&#xb47;&#xb07; &#xb2a;&#xb3e;&#xb30;&#xb3f;&#xb2c;&#xb47; &#x964; &#xb06;&#xb2a;&#xb23;&#xb19;&#xb4d;&#xb15; &#xb2a;&#xb38;&#xb28;&#xb4d;&#xb26;&#xb30; &#xb2c;&#xb3f;&#xb37;&#xb5f; &#xb17;&#xb41;&#xb21;&#xb3f;&#xb15;&#xb41; &#xb06;&#xb2a;&#xb23; &#xb28;&#xb42;&#xb24;&#xb28; &#xb2d;&#xb3e;&#xb2c;&#xb47;&#xb30;&#xb47; &#xb2f;&#xb4b;&#xb17; &#xb15;&#xb30;&#xb3f;&#xb2a;&#xb3e;&#xb30;&#xb3f;&#xb2c;&#xb47; &#xb15;&#xb3f;&#xb2e;&#xb4d;&#xb2c;&#xb3e; &#xb0f;&#xb39;&#xb3f; &#xb2a;&#xb43;&#xb37;&#xb4d;&#xb20;&#xb3e;&#xb15;&#xb41; &#xb38;&#xb2e;&#xb4d;&#xb2a;&#xb3e;&#xb26;&#xb28; &#xb15;&#xb30;&#xb3f; &#xb0f;&#xb39;&#xb3e; &#xb38;&#xb39;&#xb3f;&#xb24; &#xb2f;&#xb4b;&#xb17; &#xb15;&#xb30;&#xb3f;&#xb2a;&#xb3e;&#xb30;&#xb3f;&#xb2c; &#x964; &#xb38;&#xb2e;&#xb38;&#xb4d;&#xb24; &#xb2a;&#xb3e;&#xb20; &#xb17;&#xb41;&#xb21;&#xb3f;&#xb15; GNU &#xb2e;&#xb41;&#xb15;&#xb4d;&#xb24; &#xb26;&#xb32;&#xb3f;&#xb32;&#xb15;&#xb30;&#xb23; &#xb32;&#xb3e;&#xb07;&#xb38;&#xb47;&#xb28;&#xb4d;&#xb38;&#xb30; &#xb38;&#xb30;&#xb4d;&#xb24;&#xb4d;&#xb24; &#xb05;&#xb27;&#xb40;&#xb28;&#xb30;&#xb47; &#xb09;&#xb2a;&#xb32;&#xb2c;&#xb4d;&#xb27; &#x964; &#xb24;&#xb25;&#xb3e;&#xb2a;&#xb3f;, &#xb06;&#xb2a;&#xb23; &#xb0f;&#xb39;&#xb3e;&#xb15;&#xb41; &#xb2e;&#xb41;&#xb15;&#xb4d;&#xb24; &#xb2d;&#xb3e;&#xb2c;&#xb47;&#xb30; &#xb07;&#xb32;&#xb47;&#xb15;&#xb4d;&#xb1f;&#xb4d;&#xb30;&#xb4b;&#xb28;&#xb3f;&#xb15;&#xb4d;&#xb38; &#xb2a;&#xb4d;&#xb30;&#xb3f;&#xb23;&#xb4d;&#xb1f;&#xb4d; &#xb15;&#xb3f;&#xb2e;&#xb4d;&#xb2c;&#xb3e; &#xb05;&#xb28;&#xb4d;&#xb5f;&#xb3e;&#xb28;&#xb4d;&#xb5f; &#xb2a;&#xb4d;&#xb30;&#xb3f;&#xb23;&#xb4d;&#xb1f;&#xb30; &#xb2e;&#xb3e;&#xb27;&#xb4d;&#xb5f;&#xb2e;&#xb30;&#xb47; &#xb2c;&#xb4d;&#xb5f;&#xb2c;&#xb39;&#xb3e;&#xb30; &#xb15;&#xb30;&#xb3f;&#xb2a;&#xb3e;&#xb30;&#xb3f;&#xb2c; &#x964;
</p>

<h4>Punjabi</h4>
<p>&#xa15;&#xa47;&#xa02;&#xa26;&#xa30;&#xa40; &#xa17;&#xa4d;&#xa30;&#xa39;&#xa3f;&#xa2e;&#xa70;&#xa24;&#xa30;&#xa40; &#xa2a;&#xa40;.&#xa1a;&#xa3f;&#xa26;&#xa70;&#xa2c;&#xa30;&#xa2e; &#xa28;&#xa47; &#xa10;&#xa24;&#xa35;&#xa3e;&#xa30; &#xa28;&#xa42;&#xa70; &#xa24;&#xa2e;&#xa3f;&#xa32;&#xa28;&#xa3e;&#xa22;&#xa42; &#xa26;&#xa47; &#xa2e;&#xa41;&#xa71;&#xa16;&#xa2e;&#xa70;&#xa24;&#xa30;&#xa40; &#xa10;&#xa2e;.&#xa15;&#xa30;&#xa41;&#xa23;&#xa3e;&#xa28;&#xa3f;&#xa27;&#xa40; &#xa28;&#xa3e;&#xa32; &#xa2e;&#xa41;&#xa32;&#xa3e;&#xa15;&#xa3e;&#xa24; &#xa15;&#xa40;&#xa24;&#xa40;&#x964;&#xa09;&#xa28;&#xa4d;&#xa39;&#xa3e; &#xa28;&#xa47; &#xa36;&#xa4d;&#xa30;&#xa40;&#xa32;&#xa70;&#xa15;&#xa3e; \'&#xa1a; &#xa32;&#xa3f;&#xa71;&#xa1f;&#xa47; &#xa26;&#xa47; &#xa16;&#xa3f;&#xa32;&#xa3e;&#xa5e; &#xa2f;&#xa41;&#xa71;&#xa27; &#xa26;&#xa4c;&#xa30;&#xa3e;&#xa28; &#xa09;&#xa71;&#xa1d;&#xa5c;&#xa47; &#xa39;&#xa4b;&#xa0f; &#xa32;&#xa71;&#xa17;&#xa2d;&#xa17; &#xa22;&#xa3e;&#xa08; &#xa32;&#xa71;&#xa16; &#xa24;&#xa2e;&#xa3f;&#xa32;&#xa3e;&#xa02; &#xa26;&#xa40; &#xa2e;&#xa41;&#xa5c; &#xa30;&#xa3f;&#xa39;&#xa3e;&#xa07;&#xa36; \'&#xa24;&#xa47; &#xa1a;&#xa30;&#xa1a;&#xa3e; &#xa15;&#xa40;&#xa24;&#xa40;&#x964;
</p>

<h4>Gujarati (gu)</h4>
<p>
&#xa86; &#xab5;&#xabe;&#xaa4; &#xab9;&#xa9c;&#xabe;&#xab0; &#xab5;&#xabe;&#xab0; &#xa95;&#xab9;&#xac7;&#xab5;&#xabe;&#xaae;&#xabe;&#xa82; &#xa86;&#xab5;&#xac0; &#xa9b;&#xac7; &#xa95;&#xac7; &#xaab;&#xabf;&#xab2;&#xacd;&#xaae; &#xaac;&#xaa8;&#xabe;&#xab5;&#xaa4;&#xac0; &#xab5;&#xa96;&#xac7;&#xaa4; &#xab9;&#xa82;&#xaae;&#xac7;&#xab6;&#xabe; &#xab8;&#xacc;&#xaa5;&#xac0; &#xab5;&#xaa7;&#xac1; &#xaa7;&#xacd;&#xaaf;&#xabe;&#xaa8; &#xab5;&#xabe;&#xab0;&#xacd;&#xaa4;&#xabe; &#xa85;&#xaa8;&#xac7; &#xab8;&#xacd;&#xa95;&#xacd;&#xab0;&#xac0;&#xaa8;&#xaaa;&#xacd;&#xab2;&#xac7; &#xaaa;&#xab0; &#xa86;&#xaaa;&#xab5;&#xac1; &#xa9c;&#xacb;&#xa88;&#xa8f;. &#xa95;&#xabe;&#xab0;&#xaa3; &#xa95;&#xac7; &#xa86; &#xa95;&#xacb;&#xa88; &#xaaa;&#xaa3; &#xaab;&#xabf;&#xab2;&#xacd;&#xaae;&#xaa8;&#xac0; &#xab8;&#xaab;&#xab3;&#xaa4;&#xabe;&#xaa8;&#xacb; &#xaae;&#xac1;&#xa96;&#xacd;&#xaaf; &#xa86;&#xaa7;&#xabe;&#xab0; &#xab9;&#xacb;&#xaaf; &#xa9b;&#xac7;.
<br />
&#xaae;&#xacb;&#xa9f;&#xabe; &#xaab;&#xabf;&#xab2;&#xacd;&#xaae; &#xab8;&#xacd;&#xa9f;&#xabe;&#xab0;&#xacd;&#xab8; &#xab8;&#xabe;&#xa88;&#xaa8; &#xa95;&#xab0;&#xab5;&#xabe;&#xaa5;&#xac0;, &#xab8;&#xacd;&#xa9f;&#xa82;&#xa9f; &#xa85;&#xaa8;&#xac7; &#xa97;&#xac0;&#xaa4;&#xacb;&#xaa5;&#xac0; &#xaaa;&#xabe;&#xaa3;&#xac0;&#xaa8;&#xac0; &#xa85;&#xa82;&#xaa6;&#xab0; &#xa95;&#xac7; &#xa86;&#xa95;&#xabe;&#xab6;&#xaae;&#xabe;&#xa82; &#xa95;&#xab0;&#xacb;&#xaa1;&#xacb; &#xab0;&#xac2;&#xaaa;&#xabf;&#xaaf;&#xabe; &#xa96;&#xab0;&#xacd;&#xa9a; &#xa95;&#xab0;&#xac0; &#xaab;&#xabf;&#xab2;&#xacd;&#xaae;&#xabe;&#xab5;&#xac7;&#xab2;&#xabe; &#xaa6;&#xacd;&#xab0;&#xab6;&#xacd;&#xaaf;&#xacb;&#xaa5;&#xac0; &#xa95;&#xab6;&#xac1; &#xa9c; &#xaa8;&#xaa5;&#xac0; &#xaa5;&#xaa4;&#xac1;. &#xaaa;&#xab0;&#xa82;&#xaa4;&#xac1; &#xa86; &#xaac;&#xac1;&#xaa8;&#xabf;&#xaaf;&#xabe;&#xaa6;&#xac0; &#xab5;&#xabe;&#xaa4; &#xa85;&#xaa4;&#xacd;&#xaaf;&#xabe;&#xab0; &#xab8;&#xac1;&#xaa7;&#xac0; &#xa95;&#xacb;&#xa88; &#xab2;&#xacb;&#xa95;&#xacb;&#xaa8;&#xac7; &#xab8;&#xaae;&#xa9c;&#xabe;&#xaa4;&#xac0; &#xaa8;&#xaa5;&#xac0;.
</p>


<h4>Hindi (hi)</h4>
<p>&#x92d;&#x93e;&#x930;&#x924; &#x914;&#x930; &#x92c;&#x930;&#x92e;&#x942;&#x921;&#x93e; &#x915;&#x947; &#x92c;&#x940;&#x91a; &#x92c;&#x93e;&#x930;&#x93f;&#x936; &#x915;&#x947; &#x915;&#x93e;&#x930;&#x923; &#x930;&#x941;&#x915;&#x93e; &#x92e;&#x948;&#x91a; &#x926;&#x94b;&#x92c;&#x93e;&#x930;&#x93e; &#x936;&#x941;&#x930;&#x941; &#x939;&#x94b; &#x917;&#x92f;&#x93e; &#x939;&#x948;. &#x92d;&#x93e;&#x930;&#x924; &#x928;&#x947; &#x92c;&#x930;&#x92e;&#x942;&#x921;&#x93e; &#x915;&#x947; &#x938;&#x93e;&#x92e;&#x928;&#x947; &#x930;&#x93f;&#x915;&#x949;&#x930;&#x94d;&#x921; 414 &#x930;&#x928;&#x94b;&#x902; &#x915;&#x93e; &#x932;&#x915;&#x94d;&#x937;&#x94d;&#x92f; &#x930;&#x916;&#x93e; &#x939;&#x948;. &#x92c;&#x930;&#x92e;&#x942;&#x921;&#x93e; &#x928;&#x947; &#x926;&#x94b; &#x935;&#x93f;&#x915;&#x947;&#x91f; &#x916;&#x94b; &#x926;&#x93f;&#x90f; &#x939;&#x948;&#x902;.</p>


<h4>Nepali (ne) - Devanagari</h4>
<p>&#x905;&#x928;&#x94d;&#x924;&#x930;&#x93f;&#x92e; &#x938;&#x930;&#x915;&#x93e;&#x930;&#x915;&#x94b; &#x917;&#x920;&#x928;&#x92e;&#x93e; &#x922;&#x940;&#x932;&#x93e;&#x907; &#x939;&#x941;&#x928;&#x941;&#x915;&#x93e; &#x938;&#x93e;&#x925;&#x948; &#x906;&#x909;&#x902;&#x926;&#x94b; &#x91c;&#x947;&#x920; &#x92e;&#x939;&#x93f;&#x928;&#x93e;&#x92d;&#x93f;&#x924;&#x94d;&#x930; &#x938;&#x902;&#x935;&#x93f;&#x927;&#x93e;&#x928;&#x938;&#x92d;&#x93e;&#x915;&#x94b; &#x91a;&#x941;&#x928;&#x93e;&#x935; &#x939;&#x94b;&#x932;&#x93e; &#x915;&#x93f; &#x928;&#x939;&#x94b;&#x932;&#x93e; &#x92d;&#x928;&#x94d;&#x928;&#x947; &#x92c;&#x939;&#x938; &#x91a;&#x930;&#x94d;&#x915;&#x940;&#x930;&#x939;&#x947;&#x915;&#x94b; &#x92c;&#x947;&#x932;&#x93e; &#x91a;&#x941;&#x928;&#x93e;&#x935;&#x915;&#x948; &#x935;&#x93f;&#x937;&#x92f;&#x92e;&#x93e; &#x928;&#x93f;&#x930;&#x94d;&#x935;&#x93e;&#x91a;&#x928; &#x906;&#x92f;&#x94b;&#x917; &#x930; &#x906;&#x920; &#x926;&#x932;&#x915;&#x94b; &#x92c;&#x947;&#x917;&#x94d;&#x932;&#x93e;, &#x92c;&#x947;&#x917;&#x94d;&#x932;&#x948; &#x92d;&#x928;&#x93e;&#x907; &#x930;&#x939;&#x947;&#x915;&#x94b; &#x926;&#x947;&#x916;&#x93f;&#x90f;&#x915;&#x94b; &#x91b;&#x964;</p>


<h4>Bengali (bn)</h4>
<p>
&#x9a6;&#x995;&#x9cd;&#x9b7;&#x9bf;&#x9a3; &#x993;&#x9df;&#x9be;&#x99c;&#x9bf;&#x9b0;&#x9bf;&#x9b8;&#x9cd;&#x9a5;&#x9be;&#x9a8;&#x9c7; &#x995;&#x9b0;&#x9cd;&#x9ae;&#x9b0;&#x9a4; &#x9b8;&#x9cd;&#x9ac;&#x9c7;&#x99a;&#x9cd;&#x99b;&#x9be;&#x9b8;&#x9c7;&#x9ac;&#x9c0; &#x993; &#x9a4;&#x9cd;&#x9b0;&#x9be;&#x9a3; &#x9b8;&#x982;&#x9b8;&#x9cd;&#x9a5;&#x9be;&#x997;&#x9c1;&#x9b2;&#x9cb; &#x9a7;&#x9be;&#x9b0;&#x9a3;&#x9be; &#x995;&#x9b0;&#x99b;&#x9c7; &#x9b8;&#x9c7;&#x9a8;&#x9be; &#x985;&#x9ad;&#x9bf;&#x9af;&#x9be;&#x9a8;&#x9c7;&#x9b0; &#x9a4;&#x9c0;&#x9ac;&#x9cd;&#x9b0;&#x9a4;&#x9be; &#x9ac;&#x9be;&#x9dc;&#x9b2;&#x9c7; &#x98f;&#x987; &#x9b8;&#x982;&#x996;&#x9cd;&#x9af;&#x9be;&#x99f;&#x9be; &#x986;&#x9b0;&#x993; &#x985;&#x9a8;&#x9c7;&#x995; &#x9ac;&#x9c7;&#x9dc;&#x9c7; &#x9af;&#x9be;&#x9ac;&#x9c7;
<br />
&#x9b6;&#x9b0;&#x9a3;&#x9be;&#x9b0;&#x9cd;&#x9a5;&#x9c0;&#x9a6;&#x9c7;&#x9b0; &#x9b8;&#x9cd;&#x9b0;&#x9cb;&#x9a4; &#x9b8;&#x9be;&#x9ae;&#x9b2;&#x9be;&#x9a4;&#x9c7; &#x9a4;&#x9be;&#x9b0;&#x9be; &#x987;&#x9a4;&#x9bf;&#x9ae;&#x9a7;&#x9cd;&#x9af;&#x9c7;&#x987; &#x9b9;&#x9bf;&#x9ae;&#x9b6;&#x9bf;&#x9ae; &#x996;&#x9be;&#x99a;&#x9cd;&#x99b;&#x9c7;&#x9a8;, &#x9ab;&#x9b2;&#x9c7; &#x9b2;&#x9dc;&#x9be;&#x987; &#x9a5;&#x9c7;&#x995;&#x9c7; &#x9aa;&#x9be;&#x9b2;&#x9bf;&#x9df;&#x9c7; &#x986;&#x9b8;&#x9be; &#x9ac;&#x9c7;&#x9b8;&#x9be;&#x9ae;&#x9b0;&#x9bf;&#x995; &#x9ae;&#x9be;&#x9a8;&#x9c1;&#x9b7;&#x99c;&#x9a8;&#x9c7;&#x9b0; &#x9b8;&#x982;&#x996;&#x9cd;&#x9af;&#x9be; &#x986;&#x9b0;&#x993; &#x9ac;&#x9be;&#x9dc;&#x9b2;&#x9c7; &#x9b8;&#x9cd;&#x9ac;&#x9ad;&#x9be;&#x9ac;&#x9a4;&#x987; &#x9b8;&#x999;&#x9cd;&#x995;&#x99f; &#x986;&#x9b0;&#x993; &#x99c;&#x99f;&#x9bf;&#x9b2; &#x9b9;&#x9df;&#x9c7; &#x989;&#x9a0;&#x9ac;&#x9c7;
</p>


<h4>Assamese</h4>
<p>&#x985;&#x9b8;&#x9ae;&#x9c0;&#x9af;&#x9bc;&#x9be; &#x9f1;&#x9bf;&#x995;&#x9bf;&#x9aa;&#x9bf;&#x9a1;&#x9bf;&#x9af;&#x9bc;&#x9be;&#x9f0; &#x989;&#x9a6;&#x9cd;&#x9a6;&#x9c7;&#x9b6;&#x9cd;&#x9af; &#x9b9;\'&#x9b2; &#x9b8;&#x9ae;&#x9cd;&#x9aa;&#x9c2;&#x9f0;&#x9cd;&#x9a3; &#x985;&#x9b8;&#x9ae;&#x9c0;&#x9af;&#x9bc;&#x9be; &#x9ad;&#x9be;&#x9b7;&#x9be;&#x9a4; &#x98f;&#x996;&#x9a8;&#x9bf; &#x9ac;&#x9bf;&#x9b6;&#x9cd;&#x9ac;&#x995;&#x9cb;&#x9b7; &#x9aa;&#x9cd;&#x9f0;&#x9a3;&#x9af;&#x9bc;&#x9a8; &#x995;&#x9f0;&#x9be;&#x964; &#x985;&#x9a8;&#x9cd;&#x9af; &#x995;&#x9cb;&#x9a8;&#x9cb; &#x9ad;&#x9be;&#x9b7;&#x9be;&#x9f0; &#x9aa;&#x9cd;&#x9f0;&#x9ac;&#x9a8;&#x9cd;&#x9a7; &#x98f;&#x987; &#x9ac;&#x9bf;&#x9b6;&#x9cd;&#x9ac;&#x995;&#x9cb;&#x9b7;&#x9f0; &#x9ac;&#x9be;&#x9ac;&#x9c7; &#x997;&#x9cd;&#x9f0;&#x9b9;&#x9a8; &#x995;&#x9f0;&#x9be; &#x9a8;&#x9b9;\'&#x9ac;&#x964; &#x9ac;&#x9bf;&#x9b6;&#x9cd;&#x9ac;&#x995;&#x9cb;&#x9b7;&#x9f0; &#x985;&#x9f1;&#x9a6;&#x9be;&#x9a8;&#x995;&#x9be;&#x9f0;&#x9c0;&#x9b8;&#x995;&#x9b2;&#x9b2;&#x9c8; &#x9b8;&#x9be;&#x9a6;&#x9f0;&#x9c7;&#x9f0;&#x9c7; &#x985;&#x9a8;&#x9c1;&#x9f0;&#x9cb;&#x9a7; &#x99c;&#x9a8;&#x9cb;&#x9f1;&#x9be; &#x9b9;\'&#x9b2; &#x9af;&#x9be;&#x9a4;&#x9c7; &#x9a4;&#x9c7;&#x996;&#x9c7;&#x9a4;&#x9b8;&#x995;&#x9b2;&#x9c7; &#x985;&#x9b8;&#x9ae;&#x9c0;&#x9af;&#x9bc;&#x9be; &#x9ad;&#x9be;&#x9b7;&#x9be;&#x9f0; &#x9aa;&#x9cd;&#x9f0;&#x99a;&#x9b2;&#x9bf;&#x9a4; &#x9ac;&#x9be;&#x9a8;&#x9be;&#x9a8; &#x9aa;&#x9a6;&#x9cd;&#x9a7;&#x9a4;&#x9bf; &#x9ae;&#x9be;&#x9a8;&#x9bf; &#x99a;&#x9b2;&#x9c7;&#x964; &#x9ac;&#x9bf;&#x9a6;&#x9c7;&#x9b6;&#x9c0; &#x9b6;&#x9ac;&#x9cd;&#x9a6;&#x9f0; &#x985;&#x9b8;&#x9ae;&#x9c0;&#x9af;&#x9bc;&#x9be; &#x9aa;&#x9cd;&#x9f0;&#x9a4;&#x9bf;&#x9f0;&#x9c2;&#x9aa;&#x9f0; &#x995;&#x9cd;&#x9b7;&#x9c7;&#x9a4;&#x9cd;&#x9f0;&#x9a4; &#x9af;&#x9bf;&#x9b9;&#x9c7;&#x9a4;&#x9c1; &#x985;&#x9b8;&#x9ae;&#x9c0;&#x9af;&#x9bc;&#x9be; &#x9b8;&#x9be;&#x9b9;&#x9bf;&#x9a4;&#x9cd;&#x9af;&#x9bf;&#x995;&#x9b8;&#x995;&#x9b2; &#x98f;&#x9a4;&#x9bf;&#x9af;&#x9bc;&#x9be;&#x993; &#x990;&#x995;&#x9cd;&#x9af;&#x9ae;&#x9a4;&#x9a4; &#x989;&#x9aa;&#x9a8;&#x9c0;&#x9a4; &#x9b9;\'&#x9ac; &#x9aa;&#x9f0;&#x9be; &#x9a8;&#x9be;&#x987;, &#x9f1;&#x9bf;&#x995;&#x9bf;&#x9aa;&#x9bf;&#x9a1;&#x9bf;&#x9af;&#x9bc;&#x9be;&#x9a4; &#x9ac;&#x9bf;&#x9a6;&#x9c7;&#x9b6;&#x9c0; &#x9b6;&#x9ac;&#x9cd;&#x9a6;&#x9f0; &#x9af;&#x9bf;&#x995;&#x9cb;&#x9a8;&#x9cb; &#x9a7;&#x9f0;&#x9a8;&#x9f0; &#x985;&#x9b8;&#x9ae;&#x9c0;&#x9af;&#x9bc;&#x9be; &#x9f0;&#x9c2;&#x9aa; &#x997;&#x9cd;&#x9f0;&#x9be;&#x9b9;&#x9cd;&#x9af; &#x995;&#x9f0;&#x9be; &#x9b9;\'&#x9ac;&#x964;
</p>




<h4>Japanese (pangrams)</h4>
<h5>Iroha Uta SJIS</h5>

<p>&#x3044;&#x308d;&#x306f;&#x306b;&#x307b;&#x3078;&#x3068;&#x3000;&#x3061;&#x308a;&#x306c;&#x308b;&#x3092;&#x3000;&#x308f;&#x304b;&#x3088;&#x305f;&#x308c;&#x305d;&#x3000;&#x3064;&#x306d;&#x306a;&#x3089;&#x3080;&#x3000;&#x3046;&#x3090;&#x306e;&#x304a;&#x304f;&#x3084;&#x307e;&#x3000;&#x3051;&#x3075;&#x3053;&#x3048;&#x3066;&#x3000;&#x3042;&#x3055;&#x304d;&#x3086;&#x3081;&#x307f;&#x3057;&#x3000;&#x3091;&#x3072;&#x3082;&#x305b;&#x3059; </p>

<h5>Tori Naku Uta </h5>

<p>&#x3068;&#x308a;&#x306a;&#x304f;&#x3053;&#x3091;&#x3059;&#x3000;&#x3086;&#x3081;&#x3055;&#x307e;&#x305b;&#x3000;&#x307f;&#x3088;&#x3042;&#x3051;&#x308f;&#x305f;&#x308b;&#x3000;&#x3072;&#x3093;&#x304b;&#x3057;&#x3092;&#x3000;&#x305d;&#x3089;&#x3044;&#x308d;&#x306f;&#x3048;&#x3066;&#x3000;&#x304a;&#x304d;&#x3064;&#x3078;&#x306b;&#x3000;&#x307b;&#x3075;&#x306d;&#x3080;&#x308c;&#x3090;&#x306c;&#x3000;&#x3082;&#x3084;&#x306e;&#x3046;&#x3061; </p>

<h5>Ametsuchi No Uta </h5>

<p>&#x3042;&#x3081; &#x3064;&#x3061; &#x307b;&#x3057; &#x305d;&#x3089; / &#x3084;&#x307e; &#x304b;&#x306f; &#x307f;&#x306d; &#x305f;&#x306b; / &#x304f;&#x3082; &#x304d;&#x308a; &#x3080;&#x308d; &#x3053;&#x3051; / &#x3072;&#x3068; &#x3044;&#x306c; &#x3046;&#x3078; &#x3059;&#x3091; / &#x3086;&#x308f; &#x3055;&#x308b; &#x304a;&#x3075; &#x305b;&#x3088; / &#x3048;&#x306e;&#x3048;*&#x3092; &#x306a;&#x308c; &#x3090;&#x3066; </p>

<h5>Taini no Uta </h5>

<p>&#x305f;&#x3090;&#x306b;&#x3044;&#x3066;&#x3000;&#x306a;&#x3064;&#x3080;&#x308f;&#x308c;&#x3092;&#x305d;&#x3000;&#x304d;&#x307f;&#x3081;&#x3059;&#x3068;&#x3000;&#x3042;&#x3055;&#x308a;&#x304a;&#x3072;&#x3086;&#x304f;&#x3000;&#x3084;&#x307e;&#x3057;&#x308d;&#x306e;&#x3000;&#x3046;&#x3061;&#x3091;&#x3078;&#x308b;&#x3053;&#x3089;&#x3000;&#x3082;&#x306f;&#x307b;&#x305b;&#x3088;&#x3000;&#x3048;&#x3075;&#x306d;&#x304b;&#x3051;&#x306c; </p>

<h4>Chinese (simplified) GB2312 GB</h4>

<p>&#x6765;&#x81ea;&#x5546;&#x52a1;&#x90e8;&#x65b0;&#x95fb;&#x529e;&#x516c;&#x5ba4;&#x7684;&#x6d88;&#x606f;&#x79f0;&#xff0c;&#x4e2d;&#x65b9;&#x514d;&#x9664;&#x4e0e;&#x4e2d;&#x56fd;&#x6709;&#x5916;&#x4ea4;&#x5173;&#x7cfb;&#x7684;&#x6240;&#x6709;&#x975e;&#x6d32;&#x91cd;&#x503a;&#x7a77;&#x56fd;&#x53ca;&#x6700;&#x4e0d;&#x53d1;&#x8fbe;&#x56fd;&#x5bb6;&#x622a;&#x81f3;2005&#x5e74;&#x5e95;&#x5bf9;&#x534e;&#x5230;&#x671f;&#x653f;&#x5e9c;&#x65e0;&#x606f;&#x8d37;&#x6b3e;&#x503a;&#x52a1;&#x3002;&#x6709;&#x5173;&#x90e8;&#x95e8;&#x5df2;&#x5bf9;&#x76f8;&#x5173;&#x503a;&#x52a1;&#x8fdb;&#x884c;&#x5168;&#x9762;&#x6e05;&#x7406;&#x6838;&#x5bf9;&#xff0c;&#x5bf9;&#x4e0e;&#x4e2d;&#x56fd;&#x6709;&#x5916;&#x4ea4;&#x5173;&#x7cfb;&#x7684;33&#x4e2a;&#x975e;&#x6d32;&#x91cd;&#x503a;&#x7a77;&#x56fd;&#x548c;&#x6700;&#x4e0d;&#x53d1;&#x8fbe;&#x56fd;&#x5bb6;&#xff0c;&#x514d;&#x9664;&#x5176;&#x622a;&#x81f3;2005&#x5e74;&#x5e95;168&#x7b14;&#x5bf9;&#x534e;&#x5230;&#x671f;&#x65e0;&#x606f;&#x8d37;&#x6b3e;&#x503a;&#x52a1;&#x3002;&#x62df;&#x4e8e;2007&#x5e74;&#x5e95;&#x524d;&#x4e0e;&#x53d7;&#x63f4;&#x56fd;&#x529e;&#x7406;&#x5b8c;&#x514d;&#x503a;&#x534f;&#x8bae;&#x3002;</p>


<h4>Chinese (Traditional - Hong Kong) Big5</h4>

<p>&#x300c;&#x6182;&#x9b31;&#x5c0f;&#x738b;&#x5b50;&#x300d;&#x662f;&#x4e00;&#x500b;&#x6559;&#x80b2;&#x7db2;&#x7ad9;&#xff0c;&#x5b83;&#x6210;&#x529f;&#x7d50;&#x5408;&#x4e86;&#x9999;&#x6e2f;&#x8cfd;&#x99ac;&#x6703;&#x9632;&#x6b62;&#x81ea;&#x6bba;&#x7814;&#x7a76;&#x4e2d;&#x5fc3;&#x5404;&#x65b9;&#x9762;&#x7684;&#x5c08;&#x624d;&#xff0c;&#x70ba;&#x9752;&#x5c11;&#x5e74;&#x4eba;&#x63d0;&#x4f9b;&#x7cbe;&#x795e;&#x5065;&#x5eb7;&#x7684;&#x8a0a;&#x606f;&#xff0c;&#x5c0d;&#x666e;&#x53ca;&#x6291;&#x9b31;&#x75c7;&#x77e5;&#x8b58;&#x7684;&#x8ca2;&#x737b;&#x826f;&#x591a;&#x3002;&#x5728;&#x9999;&#x6e2f;&#xff0c;&#x5b83;&#x66fe;&#x7372;&#x9078;&#x70ba;&#x300c;2004&#x5e74;&#x5341;&#x5927;&#x5065;&#x5eb7;&#x7db2;&#x7ad9;&#x300d;&#x4e4b;&#x4e00;&#xff0c;&#x8a72;&#x9805;&#x9078;&#x8209;&#x81ea;2005&#x5e74;&#x8d77;&#x6539;&#x540d;&#x73fe;&#x6642;&#x7684;&#x300c;&#x512a;&#x79c0;&#x7db2;&#x7ad9;&#x9078;&#x8209;&#x300d;&#x3002;&#x5176;&#x8ca2;&#x737b;&#x5728;&#x570b;&#x969b;&#x9593;&#x4ea6;&#x5099;&#x53d7;&#x80af;&#x5b9a;&#xff0c;2005&#x5e74;&#xff0c;&#x8a72;&#x7db2;&#x7ad9;&#x69ae;&#x7372;&#x7b2c;&#x516b;&#x5c46;&#x300c;&#x4e9e;&#x6d32;&#x5275;&#x65b0;&#x5927;&#x734e;&#x300d;&#x9280;&#x734e;&#x3002;</p>



<h4>Korean UHC</h4>

<p>&#xd0a4;&#xc2a4;&#xc758; &#xace0;&#xc720;&#xc870;&#xac74;&#xc740; &#xc785;&#xc220;&#xb07c;&#xb9ac; &#xb9cc;&#xb098;&#xc57c; &#xd558;&#xace0; &#xd2b9;&#xbcc4;&#xd55c; &#xae30;&#xc220;&#xc740; &#xd544;&#xc694;&#xce58; &#xc54a;&#xb2e4;. </p>


<h4>Mixed</h4>
<p style="font-family: \'trebuchet ms\';">Distinguishes multiple languages enclosed in same element (tags): Arabic &#x642;&#x627;&#x644; &#x627;&#x644;&#x631;&#x626;&#x64a;&#x633;
English Cat sat on the large mat
Tamil &#xbb7;&#xbbf;&#xbaf;&#xbbe;
Hindi &#x92d;&#x93e;&#x930;&#x924; &#x914;&#x930;
Japanese &#x3044;&#x308d;&#x306f;&#x306b;&#x307b;&#x3078;&#x3068;
Chinese &#x6765;&#x81ea;&#x5546;&#x52a1;&#x90e8;&#x65b0;&#x95fb;&#x529e;&#x516c;
Thai &#xe40;&#xe1b;&#xe47;&#xe19;&#xe21;&#xe19;&#xe38;&#xe29;&#xe22;
Viet M&#xf4;&#x323;t kha&#x309;o sa&#x301;t m&#x1a1;&#x301;i cho bi&#xea;&#x301;t ng&#x1b0;&#x1a1;&#x300;i d&#xe2;n
Tamil &#xbb7;&#xbbf;&#xbaf;&#xbbe;
Chinese &#x6765;&#x81ea;&#x5546;&#x52a1;&#x90e8;&#x65b0;&#x95fb;&#x529e;&#x516c;
English Cat sat on the large mat
</p>


<h4>Unicode Plane 2</h4>
<div>
Unicode Plane 0 (BMP U+0000 - U+FFFF):
&#x9f02; &#x9f08; &#x9f17; &#x9f26; &#x9f27; &#x9f39; &#x9f44; &#x9f45; &#x9f50; &#x9f53; &#x9f5a; &#x9f62; &#x9f69; &#x9f7f; &#x9f8e; &#x9f99; &#x9f9f; &#x9fa5;
-------
Unicode Plane 2 (SIP characters > U+20000):
&#x20021; &#x2003e; &#x20046; &#x2004e; &#x20068; &#x20086; &#x20087; &#x2008a; &#x20094; &#x200ca; &#x200cb; &#x200cc; &#x200cd; &#x200d1; &#x200ee; &#x2010c; &#x2010e; &#x20118; &#x201a4; &#x201a9; &#x201ab; &#x201c1; &#x201d4; &#x201f2; &#x20204; &#x2020c; &#x20214; &#x20239; &#x2025b; &#x20274; &#x20275; &#x20299; &#x2029e; &#x202a0; &#x202b7; &#x202bf; &#x202c0; &#x202e5; &#x2030a;
-------
Unicode Plane 0 (BMPU+0000 - U+FFFF):
&#x9f02; &#x9f08; &#x9f17; &#x9f26; &#x9f27; &#x9f39; &#x9f44; &#x9f45; &#x9f50; &#x9f53; &#x9f5a; &#x9f62; &#x9f69; &#x9f7f; &#x9f8e; &#x9f99; &#x9f9f; &#x9fa5; <br />
</div>
';

$path = (getenv('MPDF_ROOT')) ? getenv('MPDF_ROOT') : __DIR__;
require_once $path . '/vendor/autoload.php';

$mpdf = new \Mpdf\Mpdf();

$mpdf->autoScriptToLang = true;
$mpdf->baseScript = 1;
$mpdf->autoVietnamese = true;
$mpdf->autoArabic = true;

$mpdf->autoLangToFont = true;

$mpdf->WriteHTML($html);

$mpdf->Output();
