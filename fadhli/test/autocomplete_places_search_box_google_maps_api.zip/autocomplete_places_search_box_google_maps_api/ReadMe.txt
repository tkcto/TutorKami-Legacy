Author: CodexWorld
Author URL: http://www.codexworld.com/
Author Email: contact@codexworld.com
Tutorial Link: http://www.codexworld.com/autocomplete-places-search-box-google-maps-javascript-api/


============ Instructions ============
1. Open the "index.html" file in a code editor ==> Specify your API Key in the Google Maps JavaScript API (Your_API_Key).

2. Open the "index.html" file on the browser ==> Start typing address in the search input field ==> The relevant places will appear in the autocomplete suggestion box ==> Select a location ==> The geolocation data of the selected location will be displayed on the webpage.


============ May I Help You ===========
If you have any query about this script, send the query by post a comment here - http://www.codexworld.com/autocomplete-places-search-box-google-maps-javascript-api/#respond