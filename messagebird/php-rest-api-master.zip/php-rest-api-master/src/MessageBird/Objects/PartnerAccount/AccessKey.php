<?php

namespace MessageBird\Objects\PartnerAccount;

use MessageBird\Objects\Base;

class AccessKey extends Base
{
    public $id;

    public $key;

    public $mode;
}
