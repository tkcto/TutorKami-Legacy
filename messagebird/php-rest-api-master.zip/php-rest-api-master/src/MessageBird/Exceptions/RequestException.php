<?php

namespace MessageBird\Exceptions;

/**
 * Class RequestException
 *
 * @package MessageBird\Exceptions
 */
class RequestException extends MessageBirdException
{
}
