<?php
include_once("config.php");
$facebook->destroy_session();
?>
Succesfully Logged out <a href="index.php">Go to Main Page</a>