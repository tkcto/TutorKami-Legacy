<?php
include_once("config.php");

if($_POST)
{
	//Post variables we received from user
	$user_page_id 	= $_POST["userpages"];
	$user_message 	= $_POST["message"];
	
	if(strlen($user_message)<1) 
	{
		//message is empty
		$user_message = 'No message was entered!';
	}
	
		//HTTP POST request to PAGE_ID/feed with the publish_stream
		$post_url = '/'.$user_page_id.'/feed';


		//posts message on page statues 
		$msg_body = array(
		'message' => $user_message,
		);
	
	if ($fbuser) {
	  try {
			$post_result = $facebook->api($post_url, 'post', $msg_body );
		} catch (facebook_api_exception $e) {
		echo $e->getMessage();
	  }
	}else{
	 $login_url = $facebook->get_login_url(array('redirect_uri'=>$home_url,'scope'=>$fb_permissions));
	 header('Location: ' . $login_url);
	}
	
	//Show sucess message
	if($post_result)
	 {
		 echo '<html><head><title>Your Message Posted</title><link href="style.css" rel="stylesheet" type="text/css" /></head><body>';
		 echo '<div id="fbpageform" class="pageform" align="center">';
		 echo '<h1>Your message has been posted on your facebook wall.</h1>';
		 echo '<a class="button" href="'.$home_url.'">Back to Main Page</a> <a target="_blank" class="button" href="http://www.facebook.com/'.$user_page_id.'">Visit Your Page</a>';
		 echo '</div>';
		 echo '</body></html>';
	 }
}
 
?>
