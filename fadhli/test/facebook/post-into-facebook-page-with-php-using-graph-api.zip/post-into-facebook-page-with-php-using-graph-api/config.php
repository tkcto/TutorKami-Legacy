<?php
include_once("include/facebook.php"); //include facebook SDK
 
######### edit details ##########
$app_id = 'YOUR_APP_ID'; //Facebook App ID
$app_secret = 'YPUR_APP_SECRET'; // Facebook App Secret
$return_url = 'http://localhost/publish_to_wall/process.php';  //return url (url to script)
$home_url = 'http://localhost/publish_to_wall/';  //return to home
$fb_permissions = 'publish_stream,manage_pages';  //Required facebook permissions
##################################

//Call Facebook API
$facebook = new Facebook(array(
  'app_id'  => $app_id,
  'secret' => $app_secret
));

$fbuser = $facebook->getUser();
?>